// Diagnostic tool - uses the REAL project headers to inspect a .semodel file's bones.
#include "wraith_types.h"
#include "semodel_reader.h"
#include <iostream>
#include <iomanip>

int main(int argc, char** argv) {
    if (argc < 2) { std::cerr << "usage: dump_bones <file.semodel>\n"; return 1; }
    SEModelReader reader;
    if (!reader.Load(argv[1])) { std::cerr << "FAILED to load " << argv[1] << "\n"; return 1; }
    WraithModel wm;
    if (!reader.Read(wm)) { std::cerr << "FAILED to parse " << argv[1] << "\n"; return 1; }

    std::cout << "=== Header flags ===\n";
    std::cout << "hasBones=" << reader.hasBones << " hasMeshes=" << reader.hasMeshes
              << " hasMats=" << reader.hasMats << "\n";
    std::cout << "hasGlobal=" << reader.hasGlobal << " hasLocal=" << reader.hasLocal
              << " hasScales=" << reader.hasScales << "\n";
    std::cout << "boneCount=" << reader.boneCount << " meshCount=" << reader.meshCount
              << " materialCount=" << reader.materialCount << "\n\n";

    std::cout << "=== Bones (" << wm.Bones.size() << " total) ===\n";
    std::cout << std::fixed << std::setprecision(3);
    for (size_t i = 0; i < wm.Bones.size(); i++) {
        auto& b = wm.Bones[i];
        std::cout << i << "\t" << b.TagName << "\tparent=" << b.BoneParent
                   << "\tlocalPos=(" << b.LocalPosition.x << "," << b.LocalPosition.y << "," << b.LocalPosition.z << ")"
                   << "\tglobalPos=(" << b.GlobalPosition.x << "," << b.GlobalPosition.y << "," << b.GlobalPosition.z << ")"
                   << "\n";
    }

    std::cout << "\n=== Root bones (parent == -1) ===\n";
    for (size_t i = 0; i < wm.Bones.size(); i++)
        if (wm.Bones[i].BoneParent < 0)
            std::cout << i << "\t" << wm.Bones[i].TagName << "\n";

    std::cout << "\n=== Bones with 'tag' or 'weapon' or 'root' in name ===\n";
    for (size_t i = 0; i < wm.Bones.size(); i++) {
        std::string lo = wm.Bones[i].TagName;
        for (auto& c : lo) c = tolower(c);
        if (lo.find("tag") != std::string::npos || lo.find("weapon") != std::string::npos || lo.find("root") != std::string::npos)
            std::cout << i << "\t" << wm.Bones[i].TagName << "\tparent=" << wm.Bones[i].BoneParent << "\n";
    }

    std::cout << "\n=== Submeshes (" << wm.Submeshes.size() << " total) ===\n";
    int totalV = 0, totalF = 0;
    for (size_t i = 0; i < wm.Submeshes.size(); i++) {
        totalV += (int)wm.Submeshes[i].Vertices.size();
        totalF += (int)wm.Submeshes[i].Faces.size();
    }
    std::cout << "total verts=" << totalV << " total faces=" << totalF << "\n";

    std::cout << "\n=== Materials (" << wm.Materials.size() << " total) ===\n";
    for (size_t i = 0; i < wm.Materials.size() && i < 20; i++)
        std::cout << i << "\t" << wm.Materials[i].MaterialName << "\tdiffuse=" << wm.Materials[i].DiffuseMapName << "\n";

    return 0;
}
