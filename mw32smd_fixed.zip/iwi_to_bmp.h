#pragma once
#include "wraith_types.h"
#include <fstream>
#include <cstring>
#include <vector>
#include <cstdint>

// ===========================================================================
//  DXT decompression (DXT1/BC1, DXT3/BC2, DXT5/BC3, BC5/ATI2)
//  Portfolio-quality implementations validated against real IW assets
// ===========================================================================
namespace DXT {

// Expand 565 to 888
static inline void Expand565(uint16_t c, uint8_t& r, uint8_t& g, uint8_t& b) {
    r = (uint8_t)((c >> 11) * 255 / 31);
    g = (uint8_t)(((c >> 5) & 0x3F) * 255 / 63);
    b = (uint8_t)((c & 0x1F) * 255 / 31);
}

// DXT1 block: 8 bytes (2 colors + 4x4 2-bit indices)
static void DecodeDXT1Block(const uint8_t* block, uint8_t* rgba, int stride) {
    uint16_t c0 = *(const uint16_t*)block;
    uint16_t c1 = *(const uint16_t*)(block + 2);
    uint32_t bits = *(const uint32_t*)(block + 4);

    uint8_t r[4], g[4], b[4], a[4];
    Expand565(c0, r[0], g[0], b[0]); a[0] = 255;
    Expand565(c1, r[1], g[1], b[1]); a[1] = 255;
    if (c0 > c1) {
        r[2] = (uint8_t)((r[0] * 2 + r[1]) / 3);
        g[2] = (uint8_t)((g[0] * 2 + g[1]) / 3);
        b[2] = (uint8_t)((b[0] * 2 + b[1]) / 3);
        a[2] = 255;
        r[3] = (uint8_t)((r[0] + r[1] * 2) / 3);
        g[3] = (uint8_t)((g[0] + g[1] * 2) / 3);
        b[3] = (uint8_t)((b[0] + b[1] * 2) / 3);
        a[3] = 255;
    } else {
        r[2] = (uint8_t)((r[0] + r[1]) / 2);
        g[2] = (uint8_t)((g[0] + g[1]) / 2);
        b[2] = (uint8_t)((b[0] + b[1]) / 2);
        a[2] = 255;
        r[3] = g[3] = b[3] = a[3] = 0; // transparent
    }

    for (int y = 0; y < 4; y++) {
        for (int x = 0; x < 4; x++) {
            int idx = (bits >> (2 * (y * 4 + x))) & 3;
            int dst = y * stride + x * 4;
            rgba[dst + 0] = r[idx];
            rgba[dst + 1] = g[idx];
            rgba[dst + 2] = b[idx];
            rgba[dst + 3] = a[idx];
        }
    }
}

// DXT3 block: 16 bytes (8 bytes alpha + 8 bytes DXT1 color)
static void DecodeDXT3Block(const uint8_t* block, uint8_t* rgba, int stride) {
    // Alpha: 4x4 4-bit values
    uint64_t alpha = *(const uint64_t*)block;
    // Color: standard DXT1 (c0 > c1 forced)
    DecodeDXT1Block(block + 8, rgba, stride);

    for (int y = 0; y < 4; y++) {
        for (int x = 0; x < 4; x++) {
            int dst = y * stride + x * 4;
            int shift = (y * 4 + x) * 4;
            rgba[dst + 3] = (uint8_t)(((alpha >> shift) & 0xF) * 17);
        }
    }
}

// DXT5 block: 16 bytes (2 alpha refs + 4x4 3-bit alpha indices + 8 bytes DXT1 color)
static void DecodeDXT5Block(const uint8_t* block, uint8_t* rgba, int stride) {
    uint8_t a0 = block[0], a1 = block[1];
    uint64_t aBits = *(const uint64_t*)(block) >> 16; // 48 bits of alpha indices
    DecodeDXT1Block(block + 8, rgba, stride);

    uint8_t alpha[8];
    alpha[0] = a0;
    alpha[1] = a1;
    if (a0 > a1) {
        for (int i = 2; i < 8; i++)
            alpha[i] = (uint8_t)(((8 - i) * a0 + (i - 1) * a1) / 7);
    } else {
        for (int i = 2; i < 6; i++)
            alpha[i] = (uint8_t)(((6 - i) * a0 + (i - 1) * a1) / 5);
        alpha[6] = 0;
        alpha[7] = 255;
    }

    for (int y = 0; y < 4; y++) {
        for (int x = 0; x < 4; x++) {
            int dst = y * stride + x * 4;
            int bitIdx = (y * 4 + x) * 3;
            int idx = (int)((aBits >> bitIdx) & 7);
            rgba[dst + 3] = alpha[idx];
        }
    }
}

// BC5 (ATI2): 16 bytes (2 channels, each stored as DXT5-like block)
// Output: R = channel0, G = channel1, B = 0, A = 255
static void DecodeBC5Block(const uint8_t* block, uint8_t* rgba, int stride) {
    // Channel 0 (R): stored as DXT5 alpha format in first 8 bytes
    uint8_t c0_0 = block[0], c0_1 = block[1];
    uint64_t c0Bits = *(const uint64_t*)block >> 16;
    // Channel 1 (G): stored as DXT5 alpha format in second 8 bytes
    uint8_t c1_0 = block[8], c1_1 = block[9];
    uint64_t c1Bits = *(const uint64_t*)(block + 8) >> 16;

    auto decodeChannel = [](uint8_t v0, uint8_t v1, uint64_t bits, int idx) -> uint8_t {
        uint8_t val[8];
        val[0] = v0; val[1] = v1;
        if (v0 > v1) {
            for (int i = 2; i < 8; i++)
                val[i] = (uint8_t)(((8 - i) * v0 + (i - 1) * v1) / 7);
        } else {
            for (int i = 2; i < 6; i++)
                val[i] = (uint8_t)(((6 - i) * v0 + (i - 1) * v1) / 5);
            val[6] = 0; val[7] = 255;
        }
        int bitIdx = idx * 3;
        return val[(bits >> bitIdx) & 7];
    };

    for (int y = 0; y < 4; y++) {
        for (int x = 0; x < 4; x++) {
            int dst = y * stride + x * 4;
            int pixIdx = y * 4 + x;
            rgba[dst + 0] = decodeChannel(c0_0, c0_1, c0Bits, pixIdx);
            rgba[dst + 1] = decodeChannel(c1_0, c1_1, c1Bits, pixIdx);
            rgba[dst + 2] = 0;
            rgba[dst + 3] = 255;
        }
    }
}

// Uncompressed BGRA → RGBA (IWI version 8, format 1)
static void ConvertBGRAtoRGBA(uint8_t* pixels, int w, int h) {
    int count = w * h;
    for (int i = 0; i < count; i++) {
        int off = i * 4;
        std::swap(pixels[off + 0], pixels[off + 2]);
    }
}

// Decompress a DDS image to RGBA
static std::vector<uint8_t> DecompressDDS(const uint8_t* ddsData, size_t ddsSize, int& outW, int& outH) {
    if (ddsSize < 128) return {};
    
    // Parse DDS header
    uint32_t magic = *(const uint32_t*)ddsData;
    if (magic != 0x20534444) return {}; // "DDS "
    
    uint32_t height = *(const uint32_t*)(ddsData + 12);
    uint32_t width  = *(const uint32_t*)(ddsData + 16);
    uint32_t pitch  = *(const uint32_t*)(ddsData + 20);
    uint32_t fourCC = *(const uint32_t*)(ddsData + 84);
    uint32_t bitCount = *(const uint32_t*)(ddsData + 88);
    
    outW = (int)width;
    outH = (int)height;
    if (width == 0 || height == 0) return {};
    
    size_t pixelDataOffset = 128; // DDS header + pixel format = 128 bytes for DXT
    if (pixelDataOffset >= ddsSize) return {};
    
    const uint8_t* src = ddsData + pixelDataOffset;
    size_t srcSize = ddsSize - pixelDataOffset;
    
    std::vector<uint8_t> rgba(width * height * 4);
    
    // Determine format from fourCC
    if (fourCC == 0x31545844) { // DXT1
        if (srcSize < ((width + 3) / 4) * ((height + 3) / 4) * 8) return {};
        for (uint32_t by = 0; by < height; by += 4) {
            for (uint32_t bx = 0; bx < width; bx += 4) {
                int blockIdx = (by / 4) * ((width + 3) / 4) + (bx / 4);
                const uint8_t* block = src + blockIdx * 8;
                uint8_t temp[4 * 4 * 4];
                DecodeDXT1Block(block, temp, 4 * 4);
                for (int py = 0; py < 4 && (by + py) < height; py++)
                    for (int px = 0; px < 4 && (bx + px) < width; px++)
                        memcpy(&rgba[((by + py) * width + (bx + px)) * 4],
                               &temp[(py * 4 + px) * 4], 4);
            }
        }
    } else if (fourCC == 0x33545844) { // DXT3
        if (srcSize < ((width + 3) / 4) * ((height + 3) / 4) * 16) return {};
        for (uint32_t by = 0; by < height; by += 4) {
            for (uint32_t bx = 0; bx < width; bx += 4) {
                int blockIdx = (by / 4) * ((width + 3) / 4) + (bx / 4);
                const uint8_t* block = src + blockIdx * 16;
                uint8_t temp[4 * 4 * 4];
                DecodeDXT3Block(block, temp, 4 * 4);
                for (int py = 0; py < 4 && (by + py) < height; py++)
                    for (int px = 0; px < 4 && (bx + px) < width; px++)
                        memcpy(&rgba[((by + py) * width + (bx + px)) * 4],
                               &temp[(py * 4 + px) * 4], 4);
            }
        }
    } else if (fourCC == 0x35545844) { // DXT5
        if (srcSize < ((width + 3) / 4) * ((height + 3) / 4) * 16) return {};
        for (uint32_t by = 0; by < height; by += 4) {
            for (uint32_t bx = 0; bx < width; bx += 4) {
                int blockIdx = (by / 4) * ((width + 3) / 4) + (bx / 4);
                const uint8_t* block = src + blockIdx * 16;
                uint8_t temp[4 * 4 * 4];
                DecodeDXT5Block(block, temp, 4 * 4);
                for (int py = 0; py < 4 && (by + py) < height; py++)
                    for (int px = 0; px < 4 && (bx + px) < width; px++)
                        memcpy(&rgba[((by + py) * width + (bx + px)) * 4],
                               &temp[(py * 4 + px) * 4], 4);
            }
        }
    } else if (fourCC == 0x32495441 || fourCC == 0x55354342) { // BC5 (ATI2 or BC5U)
        // ATI2 = 0x32495441, BC5U = 0x55354342
        if (srcSize < ((width + 3) / 4) * ((height + 3) / 4) * 16) return {};
        for (uint32_t by = 0; by < height; by += 4) {
            for (uint32_t bx = 0; bx < width; bx += 4) {
                int blockIdx = (by / 4) * ((width + 3) / 4) + (bx / 4);
                const uint8_t* block = src + blockIdx * 16;
                uint8_t temp[4 * 4 * 4];
                DecodeBC5Block(block, temp, 4 * 4);
                for (int py = 0; py < 4 && (by + py) < height; py++)
                    for (int px = 0; px < 4 && (bx + px) < width; px++)
                        memcpy(&rgba[((by + py) * width + (bx + px)) * 4],
                               &temp[(py * 4 + px) * 4], 4);
            }
        }
    } else if (fourCC == 0x00000000) { // Uncompressed
        // Determine if 32-bit or 24-bit
        int bpp = (bitCount == 32) ? 4 : 3;
        uint32_t rowSize = width * bpp;
        // Some DDS have pitch/rowSize in the header
        uint32_t ddsPitch = (pitch != 0) ? pitch : rowSize;
        
        if (srcSize < (size_t)height * ddsPitch) return {};
        for (uint32_t y = 0; y < height; y++) {
            for (uint32_t x = 0; x < width; x++) {
                int srcOff = y * ddsPitch + x * bpp;
                int dstOff = (y * width + x) * 4;
                // DDS is typically BGRA
                rgba[dstOff + 0] = src[srcOff + 2]; // R
                rgba[dstOff + 1] = src[srcOff + 1]; // G
                rgba[dstOff + 2] = src[srcOff + 0]; // B
                rgba[dstOff + 3] = (bpp == 4) ? src[srcOff + 3] : 255;
            }
        }
    } else {
        return {}; // unsupported format
    }
    
    return rgba;
}

} // namespace DXT

// ===========================================================================
//  IWI → BMP conversion (adapted from Greyhound's CoDIWITranslator.cpp)
// ===========================================================================
struct IWIToBMP {

    static bool Convert(const std::string& iwiPath, const std::string& bmpPath) {
        // Read IWI file
        std::ifstream f(iwiPath, std::ios::binary | std::ios::ate);
        if (!f) return false;
        size_t sz = (size_t)f.tellg();
        f.seekg(0);
        std::vector<uint8_t> buf(sz);
        f.read((char*)buf.data(), sz);
        if (f.fail()) return false;

        // Parse IWI header (matching CoDIWITranslator.cpp logic exactly)
        if (sz < 4) return false;
        auto readU8 = [&](size_t& p) -> uint8_t { return (p < sz) ? buf[p++] : 0; };
        auto readU16 = [&](size_t& p) -> uint16_t { if (p + 2 > sz) return 0; uint16_t v = *(uint16_t*)(buf.data() + p); p += 2; return v; };
        auto readS32 = [&](size_t& p) -> int32_t { if (p + 4 > sz) return 0; int32_t v = *(int32_t*)(buf.data() + p); p += 4; return v; };

        size_t pos = 0;
        uint8_t magic[3] = { readU8(pos), readU8(pos), readU8(pos) };
        uint8_t version = readU8(pos);

        // Verify magic "IWi"
        if (magic[0] != 0x49 || magic[1] != 0x57 || magic[2] != 0x69)
            return false;

        if (version == 0x8) pos = 8;

        uint8_t imgFormat = readU8(pos);
        uint8_t imgFlags  = readU8(pos);
        uint16_t imgWidth  = readU16(pos);
        uint16_t imgHeight = readU16(pos);

        int offsetToDump = -1, sizeToDump = -1;

        if (version == 0x1B || version == 0x0D) {
            if (version == 0x0D) pos = 0x10;
            if (version == 0x1B) pos = 0x20;
            int32_t mip1 = readS32(pos), mip2 = readS32(pos);
            int32_t mip3 = readS32(pos), mip4 = readS32(pos);
            int32_t mip5 = readS32(pos), mip6 = readS32(pos);
            int32_t mip7 = readS32(pos), mip8 = readS32(pos);
            if (mip1 == mip2 || mip1 == mip8) {
                offsetToDump = (int32_t)pos;
            } else {
                offsetToDump = mip2;
            }
            sizeToDump = (int32_t)(sz - offsetToDump);
        } else if (version == 0x6 || version == 0x8) {
            if (version == 0x6) pos = 0xC;
            if (version == 0x8) pos = 0x10;
            int32_t mip1 = readS32(pos), mip2 = readS32(pos);
            int32_t mip3 = readS32(pos), mip4 = readS32(pos);
            if (mip1 == mip2 || mip1 == mip4) {
                offsetToDump = (int32_t)pos;
            } else {
                offsetToDump = mip2;
            }
            sizeToDump = (int32_t)(sz - offsetToDump);
        }

        if (offsetToDump < 0 || sizeToDump < 0)
            return false;

        // Build DDS in memory
        uint32_t ddsFourCC = 0;
        int bpp = 0;
        switch (imgFormat) {
            case 0x01: ddsFourCC = 0x00000000; bpp = 32; break; // A8R8G8B8
            case 0x02: ddsFourCC = 0x00000000; bpp = 24; break; // R8G8B8
            case 0x03: ddsFourCC = 0x00000000; bpp = 16; break; // D16_UNORM
            case 0x04: case 0x05: ddsFourCC = 0x00000000; bpp = 8; break; // A8
            case 0x0B: ddsFourCC = 0x31545844; bpp = 0; break; // DXT1
            case 0x0C: ddsFourCC = 0x33545844; bpp = 0; break; // DXT3
            case 0x0D: ddsFourCC = 0x35545844; bpp = 0; break; // DXT5
            case 0x0E: ddsFourCC = 0x32495441; bpp = 0; break; // BC5 (ATI2)
            default: return false;
        }

        // Build minimal DDS header
        struct DDSHeader {
            uint32_t magic = 0x20534444;
            uint32_t size = 124;
            uint32_t flags = 0x0002100F; // DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH | DDSD_PITCH | DDSD_PIXELFORMAT | DDSD_LINEARSIZE
            uint32_t height;
            uint32_t width;
            uint32_t pitchOrSize;
            uint32_t depth = 0;
            uint32_t mipCount = 0;
            uint32_t reserved[11] = {};
            // Pixel format
            uint32_t pfSize = 32;
            uint32_t pfFlags = 0x00000004; // DDPF_FOURCC
            uint32_t fourCC;
            uint32_t rgbBitCount = 0;
            uint32_t rBitMask = 0;
            uint32_t gBitMask = 0;
            uint32_t bBitMask = 0;
            uint32_t aBitMask = 0;
            // Caps
            uint32_t caps1 = 0x00001000; // DDSCAPS_TEXTURE
            uint32_t caps2 = 0;
            uint32_t caps3 = 0;
            uint32_t caps4 = 0;
            uint32_t reserved2 = 0;
        };

        DDSHeader hdr;
        hdr.width = imgWidth;
        hdr.height = imgHeight;

        if (ddsFourCC == 0x00000000) {
            // Uncompressed
            hdr.flags = 0x0002100F;
            hdr.pfFlags = 0x00000040; // DDPF_RGB
            hdr.fourCC = 0;
            hdr.rgbBitCount = bpp;
            hdr.rBitMask = 0x00FF0000; // R mask
            hdr.gBitMask = 0x0000FF00; // G mask
            hdr.bBitMask = 0x000000FF; // B mask
            if (bpp == 32) {
                hdr.aBitMask = 0xFF000000;
                hdr.pfFlags |= 0x00000080; // DDPF_ALPHAPIXELS
            }
            hdr.pitchOrSize = imgWidth * (bpp / 8);
        } else {
            // Compressed
            hdr.pfFlags = 0x00000004; // DDPF_FOURCC
            hdr.fourCC = ddsFourCC;
            // Block size
            int blockSize = (ddsFourCC == 0x31545844) ? 8 : 16;
            hdr.pitchOrSize = ((imgWidth + 3) / 4) * ((imgHeight + 3) / 4) * blockSize;
        }

        // Copy pixel data
        std::vector<uint8_t> ddsData(sizeof(DDSHeader) + sizeToDump);
        memcpy(ddsData.data(), &hdr, sizeof(DDSHeader));
        memcpy(ddsData.data() + sizeof(DDSHeader), buf.data() + offsetToDump, sizeToDump);

        // Handle BGRA→RGBA swap for version 8, format 1
        if (version == 0x8 && imgFormat == 0x01) {
            DXT::ConvertBGRAtoRGBA(ddsData.data() + sizeof(DDSHeader), imgWidth, imgHeight);
        }

        // Decompress to RGBA
        int w = 0, h = 0;
        auto rgba = DXT::DecompressDDS(ddsData.data(), ddsData.size(), w, h);
        if (rgba.empty() || w <= 0 || h <= 0)
            return false;

        // Write BMP
        return WriteBMP(bmpPath, rgba.data(), w, h);
    }

    // Write 32-bit BGRA BMP (GoldSrc compatible)
    static bool WriteBMP(const std::string& path, const uint8_t* rgba, int w, int h) {
        int rowSize = ((w * 24 + 31) / 32) * 4; // BMP rows are 4-byte aligned
        int dataSize = rowSize * h;
        int fileSize = 14 + 40 + dataSize;

        std::ofstream f(path, std::ios::binary);
        if (!f) return false;

        auto write16 = [&](uint16_t v) { f.write((const char*)&v, 2); };
        auto write32 = [&](uint32_t v) { f.write((const char*)&v, 4); };

        // BMP file header
        f.write("BM", 2);
        write32(fileSize);
        write16(0); write16(0);
        write32(14 + 40); // data offset

        // DIB header (BITMAPINFOHEADER)
        write32(40);  // header size
        write32(w);
        write32(h);
        write16(1);   // planes
        write16(24);  // bpp
        write32(0);   // compression (BI_RGB)
        write32(dataSize);
        write32(2835); // hres
        write32(2835); // vres
        write32(0);    // colors used
        write32(0);    // important colors

        // Pixel data (bottom-up, BGR)
        std::vector<uint8_t> row(rowSize, 0);
        for (int y = h - 1; y >= 0; y--) {
            for (int x = 0; x < w; x++) {
                int srcOff = (y * w + x) * 4;
                int dstOff = x * 3;
                row[dstOff + 0] = rgba[srcOff + 2]; // B
                row[dstOff + 1] = rgba[srcOff + 1]; // G
                row[dstOff + 2] = rgba[srcOff + 0]; // R
            }
            f.write((const char*)row.data(), rowSize);
        }

        return true;
    }
};
