#pragma once
#include "wraith_types.h"
#include <fstream>
#include <vector>
#include <cstring>

// ===========================================================================
//  SEModel binary reader — reverse-engineered from Greyhound's SEModelExport.cpp
//  Spec: magic "SEModel" (7 bytes), version 1, header size 0x14
// ===========================================================================
struct SEModelReader {
    std::vector<uint8_t> buf;
    size_t pos = 0;

    bool Load(const std::string& path) {
        std::ifstream f(path, std::ios::binary | std::ios::ate);
        if (!f) return false;
        size_t sz = (size_t)f.tellg();
        f.seekg(0);
        buf.resize(sz);
        f.read((char*)buf.data(), sz);
        return !f.fail();
    }

    bool ReadHeader() {
        // Magic: "SEModel" (7 bytes)
        if (buf.size() < 7 + 2 + 2 + 1 + 1 + 1 + 4 + 4 + 4 + 3) return false;
        if (memcmp(buf.data(), "SEModel", 7) != 0) return false;
        pos = 7;
        uint16_t version = ReadU16();
        if (version != 1) return false;
        uint16_t headerSize = ReadU16();
        if (headerSize < 0x14) return false;
        dataPresentFlags = ReadU8();
        boneDataFlags = ReadU8();
        meshDataFlags = ReadU8();
        boneCount = ReadU32();
        meshCount = ReadU32();
        materialCount = ReadU32();
        pos += 3; // reserved
        hasBones   = (dataPresentFlags & 1) != 0;
        hasMeshes  = (dataPresentFlags & 2) != 0;
        hasMats    = (dataPresentFlags & 4) != 0;
        hasGlobal  = (boneDataFlags & 1) != 0;
        hasLocal   = (boneDataFlags & 2) != 0;
        hasScales  = (boneDataFlags & 4) != 0;
        hasUVs     = (meshDataFlags & 1) != 0;
        hasNormals = (meshDataFlags & 2) != 0;
        hasColors  = (meshDataFlags & 4) != 0;
        hasWeights = (meshDataFlags & 8) != 0;
        return true;
    }

    bool Read(WraithModel& model) {
        if (!ReadHeader()) return false;

        // ---- Bones ----
        if (hasBones) {
            model.Bones.resize(boneCount);
            // Read bone tag names
            for (uint32_t i = 0; i < boneCount; i++)
                model.Bones[i].TagName = ReadString();

            // Read bone info
            for (uint32_t i = 0; i < boneCount; i++) {
                auto& b = model.Bones[i];
                uint8_t flags = ReadU8(); (void)flags;
                b.BoneParent = ReadS32();
                if (hasGlobal) {
                    b.GlobalPosition = ReadVec3();
                    b.GlobalRotation = ReadQuat();
                }
                if (hasLocal) {
                    b.LocalPosition = ReadVec3();
                    b.LocalRotation = ReadQuat();
                }
                if (hasScales)
                    b.BoneScale = ReadVec3();
            }
        }

        // ---- Meshes ----
        if (hasMeshes) {
            model.Submeshes.resize(meshCount);
            for (uint32_t m = 0; m < meshCount; m++) {
                auto& mesh = model.Submeshes[m];
                uint8_t meshFlags = ReadU8(); (void)meshFlags;
                uint8_t matCount = ReadU8();
                uint8_t maxInfluence = ReadU8();
                uint32_t vertCount = ReadU32();
                uint32_t faceCount = ReadU32();

                mesh.Vertices.resize(vertCount);
                mesh.Faces.resize(faceCount);
                mesh.MaterialIndices.resize(matCount);

                // Positions
                for (uint32_t i = 0; i < vertCount; i++)
                    mesh.Vertices[i].Position = ReadVec3();

                // UV layers
                if (hasUVs && matCount > 0) {
                    for (uint32_t i = 0; i < vertCount; i++) {
                        for (uint32_t u = 0; u < matCount; u++) {
                            Vec2 uv = ReadVec2();
                            if (u == 0) // store only first UV layer for SMD
                                mesh.Vertices[i].UVLayers.push_back(uv);
                        }
                    }
                }

                // Normals
                if (hasNormals) {
                    for (uint32_t i = 0; i < vertCount; i++)
                        mesh.Vertices[i].Normal = ReadVec3();
                }

                // Colors
                if (hasColors) {
                    for (uint32_t i = 0; i < vertCount; i++) {
                        mesh.Vertices[i].Color[0] = ReadU8();
                        mesh.Vertices[i].Color[1] = ReadU8();
                        mesh.Vertices[i].Color[2] = ReadU8();
                        mesh.Vertices[i].Color[3] = ReadU8();
                    }
                }

                // Weights
                if (hasWeights && maxInfluence > 0) {
                    for (uint32_t i = 0; i < vertCount; i++) {
                        for (uint32_t w = 0; w < maxInfluence; w++) {
                            uint32_t idx;
                            if (boneCount <= 0xFF)       idx = ReadU8();
                            else if (boneCount <= 0xFFFF) idx = ReadU16();
                            else                         idx = ReadU32();
                            float wval = ReadF32();
                            if (wval > 0.001f)
                                mesh.Vertices[i].Weights.push_back({ idx, wval });
                        }
                    }
                } else if (hasWeights) {
                    // maxInfluence=0 means no weights present despite flag
                }

                // Faces
                for (uint32_t i = 0; i < faceCount; i++) {
                    WraithFace face;
                    if (vertCount <= 0xFF) {
                        face.Index1 = ReadU8(); face.Index2 = ReadU8(); face.Index3 = ReadU8();
                    } else if (vertCount <= 0xFFFF) {
                        face.Index1 = ReadU16(); face.Index2 = ReadU16(); face.Index3 = ReadU16();
                    } else {
                        face.Index1 = ReadU32(); face.Index2 = ReadU32(); face.Index3 = ReadU32();
                    }
                    mesh.Faces[i] = face;
                }

                // Material indices
                for (uint8_t i = 0; i < matCount; i++)
                    mesh.MaterialIndices[i] = ReadS32();
            }
        }

        // ---- Materials ----
        if (hasMats) {
            model.Materials.resize(materialCount);
            for (uint32_t i = 0; i < materialCount; i++) {
                auto& mat = model.Materials[i];
                mat.MaterialName = ReadString();
                ReadU8(); // isSimpleMaterial (bool)
                mat.DiffuseMapName = ReadString();
                mat.NormalMapName = ReadString();
                mat.SpecularMapName = ReadString();
            }
        }

        // ---- Blend shapes footer (optional) ----
        if (pos + 16 <= buf.size()) {
            uint64_t footerMagic = ReadU64();
            if (footerMagic == 0xA646E656C424553ULL) {
                uint64_t bsCount = ReadU64();
                model.BlendShapes.resize((size_t)bsCount);
                for (size_t i = 0; i < (size_t)bsCount; i++)
                    model.BlendShapes[i] = ReadString();
            } else {
                pos -= 8; // didn't match, rewind
            }
        }

        return true;
    }

    // ---- Binary reading helpers ----
    uint8_t ReadU8() { if (pos >= buf.size()) return 0; return buf[pos++]; }
    uint16_t ReadU16() { if (pos + 2 > buf.size()) return 0; uint16_t v = *(uint16_t*)(buf.data() + pos); pos += 2; return v; }
    uint32_t ReadU32() { if (pos + 4 > buf.size()) return 0; uint32_t v = *(uint32_t*)(buf.data() + pos); pos += 4; return v; }
    int32_t ReadS32() { if (pos + 4 > buf.size()) return 0; int32_t v = *(int32_t*)(buf.data() + pos); pos += 4; return v; }
    uint64_t ReadU64() { if (pos + 8 > buf.size()) return 0; uint64_t v = *(uint64_t*)(buf.data() + pos); pos += 8; return v; }
    float ReadF32() { if (pos + 4 > buf.size()) return 0; float v; memcpy(&v, buf.data() + pos, 4); pos += 4; return v; }
    Vec3 ReadVec3() { float x = ReadF32(), y = ReadF32(), z = ReadF32(); return { x, y, z }; }
    Vec2 ReadVec2() { float u = ReadF32(), v = ReadF32(); return { u, v }; }
    Quat ReadQuat() { float x = ReadF32(), y = ReadF32(), z = ReadF32(), w = ReadF32(); return { x, y, z, w }; }

    std::string ReadString() {
        std::string s;
        while (pos < buf.size() && buf[pos] != 0) s += (char)buf[pos++];
        if (pos < buf.size()) pos++; // skip null terminator
        return s;
    }

    // Header fields
    uint8_t dataPresentFlags = 0, boneDataFlags = 0, meshDataFlags = 0;
    uint32_t boneCount = 0, meshCount = 0, materialCount = 0;
    bool hasBones = false, hasMeshes = false, hasMats = false;
    bool hasGlobal = false, hasLocal = false, hasScales = false;
    bool hasUVs = false, hasNormals = false, hasColors = false, hasWeights = false;
};
