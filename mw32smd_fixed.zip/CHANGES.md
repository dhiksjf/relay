# mw32smd — hand/weapon misalignment fix

## The bug

`MergeWraithModels()` in `mw32smd.cpp` welds a weapon model's root bone onto
a named attach bone on the primary (hands) model. The old code tried to
**preserve the weapon root's original global position/rotation** when
computing its new local transform relative to the attach bone.

Weapon root bones (`j_gun` and similar) are exported at their own file's
local origin by convention — confirmed directly against your
`viewmodel_m14_sp_iw5_LOD0.semodel`: `j_gun` sits at exactly position
`(0,0,0)`, rotation identity. "Preserving" that value means the math always
solved for a local offset that reproduces `(0,0,0)` as the weapon's final
world position — i.e. every conversion welded the weapon to the **world
origin of the compiled model**, completely ignoring where the attach bone
actually is. The weapon renders as one internally-consistent piece (correct
relative to itself) sitting nowhere near the hand.

Verified with an actual before/after run: built a synthetic hand model with
an attach bone at a known position `(30,-5,10)`, ran the real merge code
against your real M14 file, and confirmed `j_gun`'s output position moved
from `(0,0,0)` (old) to exactly `(30,-5,10)` (fixed) — see
`nodes`/`skeleton` blocks in the output reference SMD.

## What changed

**`mw32smd.cpp` — `MergeWraithModels()`**
Weapon root is now welded to the attach bone with zero local offset/rotation
(the correct socket-attachment behavior) instead of solving for a transform
that preserves a meaningless always-zero source value. Prints a warning if a
future weapon file's root *isn't* near its own origin, since that would mean
this assumption doesn't hold for that file.

**`mw32smd.cpp` — `MergeWraithModels()`**
Removed duplicate scaling of merged weapon vertices/bone positions. They
were being scaled once during merge and again in `WraithModelToSmdScene()`
— invisible at `--scale 1` (the default) but would have silently corrupted
weapon positioning at any other scale factor.

**`mesh_simplify.h` — `GSOptimizer::ReduceBones()`**
Added a fixup pass so that if bone-count reduction truncates the skeleton,
no surviving bone is left with a parent pointer into the removed range.
Wasn't the active cause of your specific bug (your merged model has 51
bones, well under the 128 cap, so reduction doesn't even trigger) but it's
the same failure family and worth closing off.

**`mw32smd.cpp` — `main()`**
Added a post-merge sanity check: compares how far the newly-merged geometry
sits from the primary model against both models' own scale, and prints a
warning if it's implausibly far. Tuned so a normal long-weapon-on-compact-
hand attachment doesn't trip it — only genuine misattachment does. This is
the check that would have caught the original bug immediately, at convert
time, instead of only being visible later in a model viewer.

**`mw32smd.cpp`**
Added a missing `#include <climits>` — needed for `INT_MAX`, which MSVC
tolerates via a transitive include but stricter compilers don't. Harmless
either way, just more portable.

## Rebuild

Your existing `build.bat` / `CMakeLists.txt` work unchanged — nothing about
the build itself changed, only merge logic. The old `mw32smd.exe` /
`mw32smd.obj` are **not** included in this package since they were built
from the pre-fix source; rebuild before reconverting anything.

## Bonus: `dump_bones.cpp`

A small standalone tool (compiles the same way: `cl /EHsc /std:c++17
dump_bones.cpp`) that prints a `.semodel`'s full bone list — name, parent,
local/global position — plus flags anything with "tag"/"weapon"/"root" in
its name. Useful for checking a new weapon's actual attach-bone name and
confirming its root really is at local origin before merging it, without
running a full conversion first.
