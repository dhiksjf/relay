﻿#include "semodel_reader.h"
#include <iostream>
#include <cmath>
#include <algorithm>

static Vec3 RotVec(const Quat& q, const Vec3& v) {
    Quat pv(v.x, v.y, v.z, 0);
    Quat r = q * pv * q.Conjugate();
    return { r.x, r.y, r.z };
}

static void ComputeGlobalFromLocal(const WraithModel& wm, std::vector<Vec3>& gpos, std::vector<Quat>& grot) {
    size_t n = wm.Bones.size();
    gpos.assign(n, {});
    grot.assign(n, {});
    std::vector<bool> done(n, false);
    for (int iter = 0; iter < (int)n * 2; iter++) {
        for (size_t i = 0; i < n; i++) {
            if (done[i]) continue;
            auto& b = wm.Bones[i];
            if (b.BoneParent < 0) {
                gpos[i] = b.LocalPosition;
                grot[i] = b.LocalRotation.Normalized();
                done[i] = true;
            } else if ((size_t)b.BoneParent < n && done[b.BoneParent]) {
                int p = b.BoneParent;
                grot[i] = (grot[p] * b.LocalRotation).Normalized();
                gpos[i] = gpos[p] + RotVec(grot[p], b.LocalPosition);
                done[i] = true;
            }
        }
    }
}

static void ComputeLocalFromGlobal(const WraithModel& wm, std::vector<Vec3>& lpos, std::vector<Quat>& lrot) {
    size_t n = wm.Bones.size();
    lpos.assign(n, {});
    lrot.assign(n, {});
    for (size_t i = 0; i < n; i++) {
        auto& b = wm.Bones[i];
        if (b.BoneParent < 0) {
            lpos[i] = b.GlobalPosition;
            lrot[i] = b.GlobalRotation.Normalized();
        } else {
            auto& pb = wm.Bones[b.BoneParent];
            Quat invP = pb.GlobalRotation.Normalized().Conjugate();
            lrot[i] = (invP * b.GlobalRotation.Normalized()).Normalized();
            Vec3 diff = b.GlobalPosition - pb.GlobalPosition;
            lpos[i] = RotVec(invP, diff);
        }
    }
}

// Roundtrip via ToEuler/FromEuler
static Quat Roundtrip(const Quat& q) {
    Vec3 e = q.ToEuler();
    return Quat::FromEuler(e.x, e.y, e.z).Normalized();
}

int main(int argc, char** argv) {
    if (argc < 2) { std::cerr << "usage: diag <file.semodel>\n"; return 1; }
    SEModelReader r;
    if (!r.Load(argv[1])) { std::cerr << "load fail\n"; return 1; }
    WraithModel wm;
    if (!r.Read(wm)) { std::cerr << "read fail\n"; return 1; }
    std::cout << "bones=" << wm.Bones.size() << " hasLocal=" << r.hasLocal << " hasGlobal=" << r.hasGlobal << " hasScales=" << r.hasScales << "\n";

    // Check local->global vs stored global
    std::vector<Vec3> gpos; std::vector<Quat> grot;
    ComputeGlobalFromLocal(wm, gpos, grot);
    double maxPosErr = 0, maxRotErr = 0;
    int badPos = 0, badRot = 0;
    for (size_t i = 0; i < wm.Bones.size(); i++) {
        auto& b = wm.Bones[i];
        double pe = (gpos[i] - b.GlobalPosition).len();
        // rot error via |q1 * inv(q2) - identity|
        Quat d = (grot[i] * b.GlobalRotation.Normalized().Conjugate()).Normalized();
        double re = std::sqrt(d.x*d.x + d.y*d.y + d.z*d.z); // sin(theta/2)*2-ish
        if (pe > maxPosErr) maxPosErr = pe;
        if (re > maxRotErr) maxRotErr = re;
        if (pe > 0.01) badPos++;
        if (re > 0.01) badRot++;
        if (pe > 1.0 || re > 0.1) {
            std::cout << "  MISMATCH bone " << i << " \"" << b.TagName << "\" parent=" << b.BoneParent
                      << " posErr=" << pe << " rotErr=" << re
                      << " Lpos=(" << b.LocalPosition.x << "," << b.LocalPosition.y << "," << b.LocalPosition.z << ")"
                      << " Gpos=(" << b.GlobalPosition.x << "," << b.GlobalPosition.y << "," << b.GlobalPosition.z << ")"
                      << " recompG=(" << gpos[i].x << "," << gpos[i].y << "," << gpos[i].z << ")\n";
        }
    }
    std::cout << "Local->Global vs stored Global: maxPosErr=" << maxPosErr << " maxRotErr=" << maxRotErr
              << " badPos=" << badPos << " badRot=" << badRot << "\n";

    // Check scales
    int nonUnitScale = 0;
    for (auto& b : wm.Bones) {
        if (std::abs(b.BoneScale.x-1)>1e-4 || std::abs(b.BoneScale.y-1)>1e-4 || std::abs(b.BoneScale.z-1)>1e-4)
            nonUnitScale++;
    }
    std::cout << "non-unit scale bones: " << nonUnitScale << "\n";
    if (nonUnitScale) {
        for (size_t i=0;i<wm.Bones.size();i++) {
            auto& b = wm.Bones[i];
            if (std::abs(b.BoneScale.x-1)>1e-4 || std::abs(b.BoneScale.y-1)>1e-4 || std::abs(b.BoneScale.z-1)>1e-4)
                std::cout << "  scale bone " << i << " " << b.TagName << " (" << b.BoneScale.x << "," << b.BoneScale.y << "," << b.BoneScale.z << ")\n";
        }
    }

    // Euler roundtrip error on local rots
    double maxEulErr = 0; int badEul = 0;
    for (size_t i=0;i<wm.Bones.size();i++) {
        Quat q = wm.Bones[i].LocalRotation.Normalized();
        Quat q2 = Roundtrip(q);
        Quat d = (q2 * q.Conjugate()).Normalized();
        double re = std::sqrt(d.x*d.x + d.y*d.y + d.z*d.z);
        if (re > maxEulErr) maxEulErr = re;
        if (re > 0.05) {
            badEul++;
            Vec3 e = q.ToEuler();
            std::cout << "  EULER BAD bone " << i << " " << wm.Bones[i].TagName
                      << " err=" << re << " euler=(" << e.x << "," << e.y << "," << e.z << ")"
                      << " quat=(" << q.x << "," << q.y << "," << q.z << "," << q.w << ")\n";
        }
    }
    std::cout << "Euler roundtrip maxErr=" << maxEulErr << " bad=" << badEul << "\n";

    // Vertex bbox vs bone global bbox
    Vec3 mn, mx; bool ok=false;
    for (auto& m : wm.Submeshes) for (auto& v : m.Vertices) {
        if (!ok) { mn=mx=v.Position; ok=true; }
        else {
            mn.x=std::min(mn.x,v.Position.x); mn.y=std::min(mn.y,v.Position.y); mn.z=std::min(mn.z,v.Position.z);
            mx.x=std::max(mx.x,v.Position.x); mx.y=std::max(mx.y,v.Position.y); mx.z=std::max(mx.z,v.Position.z);
        }
    }
    if (ok) std::cout << "mesh bbox: (" << mn.x << "," << mn.y << "," << mn.z << ") - (" << mx.x << "," << mx.y << "," << mx.z << ")\n";
    Vec3 bmn, bmx; bool bok=false;
    for (auto& b : wm.Bones) {
        if (!bok) { bmn=bmx=b.GlobalPosition; bok=true; }
        else {
            bmn.x=std::min(bmn.x,b.GlobalPosition.x); bmn.y=std::min(bmn.y,b.GlobalPosition.y); bmn.z=std::min(bmn.z,b.GlobalPosition.z);
            bmx.x=std::max(bmx.x,b.GlobalPosition.x); bmx.y=std::max(bmx.y,b.GlobalPosition.y); bmx.z=std::max(bmx.z,b.GlobalPosition.z);
        }
    }
    if (bok) std::cout << "bone global bbox: (" << bmn.x << "," << bmn.y << "," << bmn.z << ") - (" << bmx.x << "," << bmx.y << "," << bmx.z << ")\n";

    // After Euler: recompute global from local eulerized
    std::vector<Vec3> lposE; std::vector<Quat> lrotE;
    for (size_t i=0;i<wm.Bones.size();i++) {
        Vec3 e = wm.Bones[i].LocalRotation.ToEuler();
        // use local pos + eulerized rot
    }
    // simulate SMD path: use Local pos + ToEuler as written
    std::vector<Vec3> gpos2(wm.Bones.size());
    std::vector<Quat> grot2(wm.Bones.size());
    std::vector<bool> done(wm.Bones.size(), false);
    for (int iter=0; iter<(int)wm.Bones.size()*2; iter++) {
        for (size_t i=0;i<wm.Bones.size();i++) {
            if (done[i]) continue;
            auto& b = wm.Bones[i];
            Vec3 e = b.LocalRotation.ToEuler();
            Quat lr = Quat::FromEuler(e.x,e.y,e.z).Normalized();
            if (b.BoneParent < 0) {
                gpos2[i] = b.LocalPosition;
                grot2[i] = lr;
                done[i] = true;
            } else if ((size_t)b.BoneParent < wm.Bones.size() && done[b.BoneParent]) {
                int p = b.BoneParent;
                grot2[i] = (grot2[p] * lr).Normalized();
                gpos2[i] = gpos2[p] + RotVec(grot2[p], b.LocalPosition);
                done[i] = true;
            }
        }
    }
    double maxPosErr2=0; int bad2=0;
    for (size_t i=0;i<wm.Bones.size();i++) {
        double pe = (gpos2[i] - wm.Bones[i].GlobalPosition).len();
        if (pe > maxPosErr2) maxPosErr2 = pe;
        if (pe > 1.0) {
            bad2++;
            std::cout << "  AFTER EULER bone " << i << " " << wm.Bones[i].TagName << " posErr=" << pe
                      << " G=(" << wm.Bones[i].GlobalPosition.x << "," << wm.Bones[i].GlobalPosition.y << "," << wm.Bones[i].GlobalPosition.z << ")"
                      << " E=(" << gpos2[i].x << "," << gpos2[i].y << "," << gpos2[i].z << ")\n";
        }
    }
    std::cout << "After Euler SMD path maxPosErr vs Global=" << maxPosErr2 << " bad=" << bad2 << "\n";
    return 0;
}
