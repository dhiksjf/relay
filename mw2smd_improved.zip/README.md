# mw32smd v2.0 Enhanced — MW3 to GoldSrc SMD Converter

A significantly improved version of the MW32SMD converter that transforms Modern Warfare 3 models (exported via Greyhound) into GoldSrc SMD format for CS 1.6 / Half-Life.

## Major Improvements Over v1.0

### 1. Enhanced Weapon Merging (`weapon_merge.h`)
- **Multi-attachment point support**: Automatically tries multiple attachment bones (`tag_weapon_left`, `tag_weapon_right`, `tag_weapon`, `j_gun`, etc.)
- **Weapon part auto-detection**: Automatically identifies and categorizes weapon parts:
  - Magazine/Clip (with empty magazine detection)
  - Bolt, Barrel, Stock, Grip
  - Scope, Iron Sight, Muzzle
  - Laser, Grenade Launcher, Bipod
  - Trigger, Receiver, Slide, Cylinder
  - Pump, Carry Handle, Silencer
  - Ammo Belt, Charging Handle, Safety
- **Weapon clip/magazine bone fix**: Ensures magazine bones are properly parented to the weapon body, not directly to the hand
- **Perfect transform computation**: Uses proper quaternion math for exact attachment positioning
- **Bone chain preservation**: Maintains full bone hierarchy for animated weapon parts (moving bolts, rotating cylinders, etc.)
- **Merge validation**: Validates the merged model to catch bone index errors

### 2. Improved UV Coordinate Precision (`smd_writer.h`, `semodel_reader.h`)
- **8 decimal place UV precision** (up from 6) for smoother texture mapping
- **All UV layers preserved** (not just the first one)
- **UV tiling support**: Uses `fmod` instead of `clamp` to preserve UV tiling information
- **No unnecessary clamping**: UV coordinates are only normalized, not clamped to [0,1]

### 3. Enhanced Animation System (`smd_writer.h`, `seanim_reader.h`)
- **Cubic Hermite interpolation**: Produces much smoother animation between keyframes
- **SLERP quaternion interpolation**: Proper spherical linear interpolation for rotations
- **Bone modifier support**: Full support for Additive, Relative, and Delta animation types
- **Notetrack extraction**: Captures animation notetracks for weapon timing events (reload sounds, fire events, etc.)
- **Scale key support**: Reads and stores scale animation keys
- **Gimbal lock detection**: Handles gimbal lock cases in Euler conversion

### 4. Maximum Detail Mode (`mesh_simplify.h`)
- **`--maxdetail` flag**: Minimal decimation to preserve maximum geometry detail
- **Hard edge preservation**: Decimation respects sharp edges (creases)
- **UV seam preservation**: Won't merge vertices across UV boundaries
- **Bone weight preservation**: Maintains proper skinning during decimation
- **Enhanced vertex clustering**: Smarter clustering that preserves visual detail

### 5. Improved Normal Handling (`semodel_reader.h`)
- **Normal validation**: Detects and fixes NaN, zero, and infinite normals
- **Automatic normalization**: Ensures all normals are unit length
- **Normal repair**: MeshRepair fixes normals that point inward

### 6. Better Material Detection (`semodel_reader.h`, `qc_writer.h`)
- **Alpha detection**: Automatically detects transparent materials from names
- **Emissive detection**: Identifies glowing materials
- **Surface property hints**: Generates surfaceprop hints in QC for metal, wood, flesh, plastic
- **Enhanced hitbox detection**: Comprehensive bone name patterns for MW3-specific skeletons

## Command-Line Options

```
Usage: mw32smd --model <file.semodel> [options]

Options:
  --model <file>       SEModel file (required)
  --merge-model <f>    Secondary SEModel to merge (e.g. weapon)
  --attach-bone <s>    Bone in primary to attach merge (default: tag_weapon_left)
  --anim <file>        SEAnim file (optional, repeat for multiple)
  --texdir <dir>       Textures directory containing .iwi files
  --outdir <dir>       Output directory (default: ./<modelname>)
  --scale <float>      Model scale factor (default: 1.0)
  --lowpoly            Force low-poly mode (<=3500 tris)
  --maxdetail          Maximum detail mode (minimal decimation)
  --maxtris <int>      Custom triangle budget
  --flipv              Flip texture V coordinate
  --maxbones <int>     Maximum bones (default: 128)
  --modeldir <path>    Model dir in QC $modelname (default: models/player)
  --help               Show help
```

## Usage Examples

### Basic Model Conversion
```bash
mw32smd --model model.semodel --texdir textures/ --outdir output/
```

### Character with Animations
```bash
mw32smd --model character.semodel --anim idle.seanim --anim run.seanim --anim fire.seanim --texdir textures/
```

### Viewmodel (Hands + Weapon) — THE BIG IMPROVEMENT
```bash
mw32smd --model viewhands_delta.semodel --merge-model weapon_ak47.semodel --attach-bone tag_weapon_left --anim fire.seanim --anim reload.seanim --maxdetail
```

### Maximum Detail Mode
```bash
mw32smd --model prop.semodel --texdir textures/ --maxdetail
```

## Weapon Merging Guide

### How It Works
1. The system reads both the hand/arm model and the weapon model
2. It detects the attachment bone in the hand model (default: `tag_weapon_left`)
3. It auto-detects all weapon parts from bone names
4. It computes the exact transform to attach the weapon root to the hand
5. It merges the bone hierarchies, ensuring weapon parts maintain proper parent chains
6. Magazine/clip bones are specially handled to ensure they animate correctly

### Supported Weapon Part Bones
The system recognizes these naming patterns:
- **Magazine**: `mag`, `clip`, `magazine`, `j_mag`, `tag_mag`, `tag_clip`
- **Bolt**: `bolt`, `j_bolt`
- **Barrel**: `barrel`, `j_barrel`
- **Stock**: `stock`, `j_stock`, `tag_stock`, `butt`
- **Scope**: `scope`, `optic`, `acog`, `redot`, `holo`, `j_scope`
- **Grip**: `grip` (with `fore`)
- **Muzzle**: `muzzle`, `flash`, `brake`
- **Laser**: `laser`
- **Silencer**: `silencer`, `suppress`
- **And many more...**

### Perfect Attachment
The weapon root bone is attached using proper quaternion math:
1. Compute global transforms for both models
2. Get the attachment bone's global rotation
3. Calculate: `Q_local = inverse(Q_attach) * Q_weapon`
4. Calculate: `P_local = inverse(Q_attach) * (P_weapon - P_attach)`
5. This ensures the weapon is perfectly oriented to the hand

## Building

### With Visual Studio (Windows)
```batch
# Open "x64 Native Tools Command Prompt"
cl /nologo /EHsc /std:c++17 /Fe: mw32smd.exe mw32smd.cpp /link gdiplus.lib
```

### With CMake
```bash
mkdir build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release
cmake --build . --config Release
```

## File Structure

```
mw32smd/
├── mw32smd.cpp           # Main converter
├── weapon_merge.h        # Enhanced weapon merging system
├── semodel_reader.h      # SEModel reader (improved UV/normals)
├── seanim_reader.h       # SEAnim reader (bone modifiers/notetracks)
├── smd_writer.h          # SMD writer (precision/interpolation)
├── mesh_simplify.h       # Mesh optimizer (detail preservation)
├── qc_writer.h           # QC script generator (enhanced hitboxes)
├── iwi_to_bmp.h          # IWI texture converter
├── wraith_types.h        # Data structures (weapon parts/enhanced types)
├── CMakeLists.txt        # CMake build file
└── README.md             # This file
```

## GoldSrc Limits

The converter enforces these GoldSrc limits:
- **4096** unique vertices per body
- **20,000** triangles per body
- **128** bones total
- **32** bodygroups maximum
- Texture resolution up to **1024x1024**
- **64** character bone names
- **64** character texture names

## Technical Details

### UV Precision
UV coordinates are written with 10 decimal places of precision in the SMD file. The system preserves UV tiling by using `fmod()` instead of `clamp()`, so textures that tile across the model will still tile correctly.

### Animation Interpolation
The system uses cubic Hermite spline interpolation for position keys and SLERP (spherical linear interpolation) for rotation keys. This produces much smoother animation than the linear interpolation used in v1.0.

### Mesh Decimation
When decimation is needed (to fit within GoldSrc limits), the system uses a grid-based vertex clustering approach that:
1. Groups nearby vertices into clusters
2. Averages their positions, normals, and UVs
3. Rebuilds triangles from the clustered data
4. Preserves hard edges and UV seams in maximum detail mode

## Credits

Based on the original mw32smd v1.0 with significant enhancements for:
- Better weapon merging with proper attachment
- Improved UV and animation quality
- Maximum detail preservation
- Weapon part detection and handling
