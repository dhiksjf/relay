#pragma once
#include "wraith_types.h"
#include <fstream>
#include <cstdio>
#include <algorithm>
#include <unordered_set>

// ===========================================================================
//  SMD Writer — Enhanced with UV precision fixes and improved animation
//  Improvements:
//    - Double-precision UV coordinates (no premature clamping)
//    - Better animation interpolation (cubic for smoother results)
//    - Full weight list support where possible
//    - Proper Source Engine format compatibility
// ===========================================================================
struct SMDWriter {

    // Write reference (model) SMD from a SmdScene
    static bool WriteRefSMD(const std::string& path, const SmdScene& scene) {
        std::ofstream f(path);
        if (!f) return false;

        f << "version 1\n";

        // Nodes
        f << "nodes\n";
        for (auto& b : scene.bones) {
            f << b.index << " \"" << b.name << "\" " << b.parent << "\n";
        }
        f << "end\n";

        // Skeleton (reference pose, time 0)
        f << "skeleton\n";
        f << "time 0\n";
        for (auto& b : scene.bones) {
            char buf[256];
            // Use higher precision for position to avoid vertex snapping
            std::snprintf(buf, sizeof(buf), "%d %.10f %.10f %.10f %.10f %.10f %.10f\n",
                b.index, b.pos.x, b.pos.y, b.pos.z, b.rot.x, b.rot.y, b.rot.z);
            f << buf;
        }
        f << "end\n";

        // Triangles with enhanced UV precision
        f << "triangles\n";
        for (auto& tri : scene.tris) {
            f << tri.tex << "\n";
            for (int i = 0; i < 3; i++) {
                auto& v = tri.v[i];

                // Enhanced UV handling:
                // 1. Keep UV precision with 8 decimal places
                // 2. Only clamp if explicitly outside reasonable bounds
                // 3. Support UV tiling by NOT clamping to [0,1] for Source Engine
                double u = v.uv.u;
                double v_ = v.uv.v;

                // For GoldSrc compatibility, we still need UVs in [0,1]
                // but we keep higher precision
                // Use fmod for tiling instead of clamp
                u = std::fmod(u, 1.0);
                if (u < 0) u += 1.0;
                v_ = std::fmod(v_, 1.0);
                if (v_ < 0) v_ += 1.0;

                // Write vertex with multi-bone weight support
                // SMD format: bone x y z nx ny nz u v [numLinks bone1 weight1 bone2 weight2 ...]
                std::string weightSuffix;
                if (!v.weights.empty()) {
                    // Count unique bones and their weights
                    std::vector<std::pair<int, float>> boneWeights;
                    for (auto& bw : v.weights) {
                        if (bw.weight > 0.001f) {
                            bool found = false;
                            for (auto& existing : boneWeights) {
                                if (existing.first == bw.bone) {
                                    existing.second += bw.weight;
                                    found = true;
                                    break;
                                }
                            }
                            if (!found) {
                                boneWeights.push_back({ bw.bone, bw.weight });
                            }
                        }
                    }
                    // Sort by weight descending
                    std::sort(boneWeights.begin(), boneWeights.end(),
                        [](const auto& a, const auto& b) { return a.second > b.second; });
                    // Build suffix: numLinks bone1 weight1 bone2 weight2 ...
                    weightSuffix = " " + std::to_string((int)boneWeights.size());
                    for (auto& bw : boneWeights) {
                        char wb[32];
                        std::snprintf(wb, sizeof(wb), " %d %.6f", bw.first, bw.second);
                        weightSuffix += wb;
                    }
                }

                char buf[512];
                std::snprintf(buf, sizeof(buf),
                    "%d %.10f %.10f %.10f %.10f %.10f %.10f %.8f %.8f%s\n",
                    v.bone,
                    v.pos.x, v.pos.y, v.pos.z,
                    v.nrm.x, v.nrm.y, v.nrm.z,
                    u, v_,
                    weightSuffix.c_str());
                f << buf;
            }
        }
        f << "end\n";

        return true;
    }

    // Write animation SMD from a SmdAnim with enhanced interpolation
    static bool WriteAnimSMD(const std::string& path, const SmdScene& refScene, const SmdAnim& anim) {
        std::ofstream f(path);
        if (!f) return false;

        f << "version 1\n";

        // Nodes (must match reference SMD)
        f << "nodes\n";
        for (auto& b : refScene.bones) {
            f << b.index << " \"" << b.name << "\" " << b.parent << "\n";
        }
        f << "end\n";

        // Skeleton (per-frame)
        f << "skeleton\n";
        int nBones = (int)refScene.bones.size();
        for (int fi = 0; fi < anim.frames; fi++) {
            f << "time " << fi << "\n";
            for (int bi = 0; bi < nBones && bi < (int)anim.data[fi].size(); bi++) {
                auto& frame = anim.data[fi][bi];
                char buf[256];
                // Higher precision for smoother animation
                std::snprintf(buf, sizeof(buf),
                    "%d %.10f %.10f %.10f %.10f %.10f %.10f\n",
                    bi,
                    frame.pos.x, frame.pos.y, frame.pos.z,
                    frame.rot.x, frame.rot.y, frame.rot.z);
                f << buf;
            }
        }
        f << "end\n";

        return true;
    }

    // Convert WraithAnim to SmdAnim with enhanced interpolation
    static SmdAnim ConvertAnim(const WraithAnim& wAnim, const SmdScene& refScene) {
        SmdAnim anim;
        anim.name = wAnim.AssetName;
        anim.fps = wAnim.FrameRate;
        anim.loop = wAnim.Looping;
        anim.animType = wAnim.AnimType;
        anim.notetracks.reserve(wAnim.AnimationNotetracks.size());
        for (auto& [note, frames] : wAnim.AnimationNotetracks) {
            anim.notetracks[note] = std::vector<int>(frames.begin(), frames.end());
        }

        int origFrames = (int)wAnim.FrameCount();
        if (origFrames < 1) origFrames = 1;
        bool hasLoopFrame = (anim.loop && origFrames > 1);
        anim.frames = origFrames + (hasLoopFrame ? 1 : 0);

        std::vector<std::string> boneNames;
        for (auto& b : refScene.bones)
            boneNames.push_back(b.name);
        int nBones = (int)boneNames.size();
        anim.data.resize(anim.frames, std::vector<SmdAnim::Frame>(nBones));

        // Phase 1: default all frames to reference pose
        for (int fi = 0; fi < anim.frames; fi++) {
            for (int bi = 0; bi < nBones; bi++) {
                anim.data[fi][bi].pos = refScene.bones[bi].pos;
                anim.data[fi][bi].rot = refScene.bones[bi].rot;
            }
        }

        // Phase 2: overlay position keys with cubic interpolation
        for (auto& [boneName, keys] : wAnim.AnimationPositionKeys) {
            int bi = -1;
            for (int i = 0; i < nBones; i++) {
                if (boneNames[i] == boneName) { bi = i; break; }
            }
            if (bi < 0) continue;
            for (auto& key : keys) {
                int fi = (int)key.Frame;
                if (fi < origFrames)
                    anim.data[fi][bi].pos = { key.Value.x, key.Value.y, key.Value.z };
            }
        }

        // Phase 3: overlay rotation keys with SLERP
        for (auto& [boneName, keys] : wAnim.AnimationRotationKeys) {
            int bi = -1;
            for (int i = 0; i < nBones; i++) {
                if (boneNames[i] == boneName) { bi = i; break; }
            }
            if (bi < 0) continue;
            for (auto& key : keys) {
                int fi = (int)key.Frame;
                if (fi < origFrames) {
                    Quat q = key.Value;
                    anim.data[fi][bi].rot = q.ToEuler();
                }
            }
        }

        // Phase 4: enhanced cubic position interpolation between keyframes
        for (auto& [boneName, keys] : wAnim.AnimationPositionKeys) {
            int bi = -1;
            for (int i = 0; i < nBones; i++) {
                if (boneNames[i] == boneName) { bi = i; break; }
            }
            if (bi < 0 || keys.size() < 2) continue;
            for (size_t ki = 0; ki + 1 < keys.size(); ki++) {
                int f0 = (int)keys[ki].Frame;
                int f1 = (int)keys[ki + 1].Frame;
                if (f1 <= f0) continue;
                Vec3 v0 = { keys[ki].Value.x, keys[ki].Value.y, keys[ki].Value.z };
                Vec3 v1 = { keys[ki + 1].Value.x, keys[ki + 1].Value.y, keys[ki + 1].Value.z };

                // Compute tangents for cubic interpolation
                Vec3 t0, t1;
                if (ki > 0) {
                    Vec3 vm1 = { keys[ki - 1].Value.x, keys[ki - 1].Value.y, keys[ki - 1].Value.z };
                    t0 = (v1 - vm1) * 0.5;
                } else {
                    t0 = v1 - v0;
                }
                if (ki + 2 < keys.size()) {
                    Vec3 v2 = { keys[ki + 2].Value.x, keys[ki + 2].Value.y, keys[ki + 2].Value.z };
                    t1 = (v2 - v0) * 0.5;
                } else {
                    t1 = v1 - v0;
                }

                double gap = (double)(f1 - f0);
                for (int f = f0 + 1; f < f1 && f < origFrames; f++) {
                    double t = (double)(f - f0) / gap;
                    // Cubic Hermite interpolation for smoother motion
                    double t2 = t * t;
                    double t3 = t2 * t;
                    double h0 = 2 * t3 - 3 * t2 + 1;
                    double h1 = -2 * t3 + 3 * t2;
                    double h2 = t3 - 2 * t2 + t;
                    double h3 = t3 - t2;

                    Vec3 mw3 = {
                        h0 * v0.x + h1 * v1.x + h2 * t0.x * gap + h3 * t1.x * gap,
                        h0 * v0.y + h1 * v1.y + h2 * t0.y * gap + h3 * t1.y * gap,
                        h0 * v0.z + h1 * v1.z + h2 * t0.z * gap + h3 * t1.z * gap
                    };
                    anim.data[f][bi].pos = mw3;
                }
            }
        }

        // Phase 5: SLERP rotation between keyframes
        for (auto& [boneName, keys] : wAnim.AnimationRotationKeys) {
            int bi = -1;
            for (int i = 0; i < nBones; i++) {
                if (boneNames[i] == boneName) { bi = i; break; }
            }
            if (bi < 0 || keys.size() < 2) continue;
            for (size_t ki = 0; ki + 1 < keys.size(); ki++) {
                int f0 = (int)keys[ki].Frame;
                int f1 = (int)keys[ki + 1].Frame;
                if (f1 <= f0) continue;
                Quat q0 = keys[ki].Value;
                Quat q1 = keys[ki + 1].Value;

                double gap = (double)(f1 - f0);
                for (int f = f0 + 1; f < f1 && f < origFrames; f++) {
                    double t = (double)(f - f0) / gap;
                    Quat qs = Quat::Slerp(q0, q1, t);
                    anim.data[f][bi].rot = qs.ToEuler();
                }
            }
        }

        // Phase 6: unwrap Euler angles across frames to prevent discontinuities
        for (int bi = 0; bi < nBones; bi++) {
            for (int fi = 1; fi < anim.frames; fi++) {
                auto& prev = anim.data[fi - 1][bi].rot;
                auto& curr = anim.data[fi][bi].rot;
                auto uw = [](double& v, double r) {
                    while (v - r > 3.14159265) v -= 6.2831853;
                    while (v - r < -3.14159265) v += 6.2831853;
                };
                uw(curr.x, prev.x); uw(curr.y, prev.y); uw(curr.z, prev.z);
            }
        }

        // Phase 7: duplicate frame 0 at end for smooth looping
        if (hasLoopFrame) anim.data.back() = anim.data[0];

        return anim;
    }
};
