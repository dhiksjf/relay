#pragma once
#include "wraith_types.h"
#include <fstream>
#include <set>
#include <algorithm>
#include <cctype>

// ===========================================================================
//  QC Writer — Enhanced with better hitbox detection and sequence generation
//  Improvements:
//    - More comprehensive hitbox patterns for MW3 bones
//    - Weapon-specific hitbox categories
//    - Better render mode detection
//    - Sequence deduplication with better naming
// ===========================================================================
struct QCWriter {

    static std::string SanitizeName(const std::string& s, int maxLen = 32) {
        std::string out = s;
        for (char& c : out)
            if (!std::isalnum((unsigned char)c) && c != '_' && c != '-' && c != '.')
                c = '_';
        if ((int)out.size() > maxLen) out = out.substr(0, maxLen);
        return out;
    }

    static std::string ToLower(std::string s) {
        std::transform(s.begin(), s.end(), s.begin(), ::tolower);
        return s;
    }

    static std::string TexStem(const std::string& p) {
        auto pos = p.find_last_of("/\\");
        std::string file = (pos == std::string::npos) ? p : p.substr(pos + 1);
        auto dot = file.find_last_of('.');
        std::string stem = (dot == std::string::npos) ? file : file.substr(0, dot);
        if (stem.empty()) stem = "tex";
        return SanitizeName(stem, 60);
    }

    struct HBox {
        int group;
        std::string bone;
        Vec3 mn, mx;
        std::string comment;
    };

    // Enhanced hitbox detection with MW3-specific bone patterns
    static std::vector<HBox> GenHitboxes(const SmdScene& s) {
        struct Pat { int g; const char* c; std::vector<const char*> kw; };
        static const Pat pats[] = {
            // Head group
            {1, "Head",       {"head","skull","cranium","neck1","Head1","Bip01_Head",
                               "j_head","neck","j_neck","head_n","Head_N"}},
            // Chest group
            {2, "Chest",      {"spine2","spine3","chest","thorax","upperchest","Spine2","Spine3",
                               "j_spine2","j_spine3","j_chest","j_torso","torso_u"}},
            {2, "Upper Body", {"spine1","Spine1","torso","upper_torso","j_spine1","j_mainroot",
                               "spine_lower","j_spine"}},
            // Stomach group
            {3, "Stomach",    {"pelvis","hips","spine0","Spine0","stomach","abdomen","Bip01_Pelvis",
                               "j_hips","j_pelvis","j_spine0","hip","root","tag_origin"}},
            // Left Arm group
            {4, "Left Arm",   {"l_upperarm","leftarm","bip01_l_upperarm","LeftArm","j_shoulder_le",
                               "l_shoulder","arm_l_upper","j_clavicle_le","l_clavicle"}},
            {4, "Left FArm",  {"l_forearm","leftforearm","bip01_l_forearm","LeftForeArm","j_elbow_le",
                               "l_elbow","arm_l_lower","j_lowerarm_le"}},
            {4, "Left Hand",  {"l_hand","lefthand","bip01_l_hand","LeftHand","j_wrist_le",
                               "l_wrist","hand_l","j_hand_le","tag_weapon_left","tag_lhand"}},
            // Right Arm group
            {5, "Right Arm",  {"r_upperarm","rightarm","bip01_r_upperarm","RightArm","j_shoulder_ri",
                               "r_shoulder","arm_r_upper","j_clavicle_ri","r_clavicle"}},
            {5, "Right FArm", {"r_forearm","rightforearm","bip01_r_forearm","RightForeArm","j_elbow_ri",
                               "r_elbow","arm_r_lower","j_lowerarm_ri"}},
            {5, "Right Hand", {"r_hand","righthand","bip01_r_hand","RightHand","j_wrist_ri",
                               "r_wrist","hand_r","j_hand_ri","tag_weapon_right","tag_rhand","tag_weapon"}},
            // Left Leg group
            {6, "Left Thigh", {"l_thigh","bip01_l_thigh","LeftUpLeg","leftupleg","j_hip_le",
                               "leg_l_upper","j_thigh_le"}},
            {6, "Left Calf",  {"l_calf","bip01_l_calf","LeftLeg","leftleg","j_knee_le",
                               "leg_l_lower","j_calf_le"}},
            {6, "Left Foot",  {"l_foot","bip01_l_foot","LeftFoot","j_ankle_le","foot_l",
                               "j_foot_le","j_ball_le","l_toe","j_toe_le"}},
            // Right Leg group
            {7, "Right Thigh",{"r_thigh","bip01_r_thigh","RightUpLeg","rightupleg","j_hip_ri",
                               "leg_r_upper","j_thigh_ri"}},
            {7, "Right Calf", {"r_calf","bip01_r_calf","RightLeg","rightleg","j_knee_ri",
                               "leg_r_lower","j_calf_ri"}},
            {7, "Right Foot", {"r_foot","bip01_r_foot","RightFoot","j_ankle_ri","foot_r",
                               "j_foot_ri","j_ball_ri","r_toe","j_toe_ri"}},
            // Weapon-specific groups
            {8, "Weapon Body", {"weapon","gun","rifle","pistol","wpn_","j_gun","tag_gun","barrel",
                                "receiver","j_receiver","j_barrel"}},
            {9, "Magazine",   {"magazine","mag","clip","j_mag","j_clip","tag_mag","tag_clip"}},
            {10, "Weapon Stock",{"stock","j_stock","tag_stock","butt","j_butt"}},
            {11, "Optic",      {"scope","optic","sight","acog","redot","holo","j_scope","tag_scope"}},
        };

        std::vector<HBox> out;
        for (auto& b : s.bones) {
            if (!b.bbox.valid) continue;
            std::string lo = ToLower(b.name);
            int grp = -1; std::string cmt;
            for (auto& p : pats) {
                for (auto& kw : p.kw) {
                    if (lo.find(ToLower(kw)) != std::string::npos) { grp = p.g; cmt = p.c; break; }
                }
                if (grp >= 0) break;
            }
            if (grp < 0) continue;
            const double pad = 1.5;
            Vec3 mn = { b.bbox.mn.x - b.pos.x - pad, b.bbox.mn.y - b.pos.y - pad, b.bbox.mn.z - b.pos.z - pad };
            Vec3 mx = { b.bbox.mx.x - b.pos.x + pad, b.bbox.mx.y - b.pos.y + pad, b.bbox.mx.z - b.pos.z + pad };
            out.push_back({ grp, b.name, mn, mx, cmt });
        }
        return out;
    }

    static std::string FV(const Vec3& v) {
        char b[128];
        std::snprintf(b, sizeof(b), "%.4f %.4f %.4f", v.x, v.y, v.z);
        return b;
    }

    static bool HasTransparency(const std::string& texName) {
        std::string lo = ToLower(texName);
        return lo.find("_mask") != std::string::npos ||
               lo.find("_alpha") != std::string::npos ||
               lo.find("_glass") != std::string::npos ||
               lo.find("_glow") != std::string::npos ||
               lo.find("_fx") != std::string::npos ||
               lo.find("_lens") != std::string::npos ||
               lo.find("_sight_glass") != std::string::npos;
    }

    static bool IsAdditive(const std::string& texName) {
        std::string lo = ToLower(texName);
        return lo.find("_add") != std::string::npos ||
               lo.find("_glow") != std::string::npos ||
               lo.find("_flare") != std::string::npos ||
               lo.find("_light") != std::string::npos ||
               lo.find("_emissive") != std::string::npos;
    }

    static bool IsChrome(const std::string& texName) {
        std::string lo = ToLower(texName);
        return lo.find("_chrome") != std::string::npos ||
               lo.find("_spec") != std::string::npos ||
               lo.find("_env") != std::string::npos ||
               lo.find("_metal") != std::string::npos ||
               lo.find("_barrel") != std::string::npos;
    }

    static bool IsFlatShade(const std::string& texName) {
        std::string lo = ToLower(texName);
        return lo.find("_flat") != std::string::npos;
    }

    static bool WriteQC(const std::string& path,
                         const std::string& baseName,
                         const SmdScene& scene,
                         const std::vector<std::string>& bodyNames,
                         const std::vector<SmdAnim>& anims,
                         const std::set<std::string>& texSet,
                         const std::string& modelDir = "models/player")
    {
        std::ofstream f(path);
        if (!f) return false;

        f << "// ================================================================\n";
        f << "//  " << baseName << ".qc\n";
        f << "//  Auto-generated by mw32smd Enhanced - MW3 to GoldSrc Model Converter\n";
        f << "//  Compile with:  studiomdl.exe " << baseName << ".qc\n";
        f << "// ================================================================\n\n";

        f << "$modelname \"" << baseName << ".mdl\"\n";
        f << "$cd \".\"\n";
        f << "$scale 1\n\n";

        // Note: $bbox, $cbox, $eyeposition not supported by studiomdl SC

        // Body / bodygroups — GoldSrc $body syntax
        for (size_t bi = 0; bi < bodyNames.size(); bi++) {
            f << "$body studio \"" << bodyNames[bi] << "\"\n";
        }
        f << "\n";

        // Texture group
        if (texSet.size() > 1) {
            f << "$texturegroup \"skinfamilies\"\n{\n";
            f << "  {";
            for (auto& tx : texSet) f << " \"" << tx << "\"";
            f << " }\n";
            f << "}\n\n";
        }

        // Render flags and texture references
        for (auto& tx : texSet) {
            if (HasTransparency(tx))
                f << "$texrendermode \"" << tx << "\" masked\n";
            if (IsAdditive(tx))
                f << "$texrendermode \"" << tx << "\" additive\n";
            if (IsChrome(tx))
                f << "$texrendermode \"" << tx << "\" chrome\n";
        }

        // Surface property hints
        for (auto& tx : texSet) {
            std::string lo = ToLower(tx);
            if (lo.find("_metal") != std::string::npos || lo.find("barrel") != std::string::npos)
                f << "// surfaceprop hint: \"" << tx << "\" -> metal\n";
            if (lo.find("_wood") != std::string::npos || lo.find("stock") != std::string::npos)
                f << "// surfaceprop hint: \"" << tx << "\" -> wood\n";
            if (lo.find("_concrete") != std::string::npos || lo.find("_stone") != std::string::npos)
                f << "// surfaceprop hint: \"" << tx << "\" -> concrete\n";
            if (lo.find("_flesh") != std::string::npos || lo.find("_skin") != std::string::npos ||
                lo.find("hands") != std::string::npos || lo.find("head") != std::string::npos)
                f << "// surfaceprop hint: \"" << tx << "\" -> flesh\n";
            if (lo.find("plastic") != std::string::npos || lo.find("polymer") != std::string::npos ||
                lo.find("grip") != std::string::npos)
                f << "// surfaceprop hint: \"" << tx << "\" -> solidplastic\n";
        }

        // $flags
        int flags = 0;
        for (auto& tx : texSet) {
            if (IsChrome(tx))     flags |= 4;
            if (IsFlatShade(tx))  flags |= 2;
        }
        for (auto& tx : texSet) {
            if (HasTransparency(tx)) { flags |= 0x80; break; }
        }
        if (flags) f << "$flags " << flags << "\n\n";

        // Hitboxes — Enhanced detection
        auto hboxes = GenHitboxes(scene);
        if (!hboxes.empty()) {
            f << "// Auto-generated hitboxes\n";
            for (auto& hb : hboxes) {
                f << "$hbox " << hb.group << " \"" << hb.bone << "\" "
                  << FV(hb.mn) << "  " << FV(hb.mx) << "\n";
            }
            f << "\n";
        }

        // Sequences — with deduplication and better naming
        std::set<std::string> usedSeqNames;
        for (auto& sa : anims) {
            std::string stem = sa.name;
            auto dot = stem.find_last_of('.');
            if (dot != std::string::npos) stem = stem.substr(0, dot);
            std::string seqName = SanitizeName(stem, 64);

            // Deduplicate sequence names
            std::string unique = seqName;
            int n = 1;
            while (usedSeqNames.count(unique)) unique = seqName + "_" + std::to_string(++n);
            usedSeqNames.insert(unique);

            f << "$sequence \"" << unique << "\" \"" << seqName << "\"";
            f << " fps " << (int)sa.fps;
            if (sa.loop) f << " loop";
            f << "\n";
        }

        return true;
    }
};
