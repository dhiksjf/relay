// ===========================================================================
//  mw32smd v2.0 Enhanced — MW3 SEModel/SEAnim/IWI → GoldSrc SMD/QC/BMP
//
//  Major improvements over v1.0:
//    - Enhanced weapon merging with multi-attachment support
//    - Weapon part auto-detection (magazine, bolt, barrel, etc.)
//    - Improved UV coordinate precision (8 decimal places)
//    - Cubic Hermite animation interpolation for smoother results
//    - Maximum detail mode with minimal decimation
//    - Weapon clip/magazine bone fix
//    - Bone modifier support (Additive/Relative/Delta animations)
//    - Notetrack extraction for weapon timing events
//    - Better normal validation and repair
//    - Hard edge and UV seam preservation during decimation
//
//  Input:  .semodel (binary)  — model data
//          .seanim  (binary)  — animation data (optional)
//          .iwi     (binary)  — texture data (optional)
//
//  Output: .smd (reference)   — one per body
//          .smd (animation)   — one per animation
//          .qc                — studiomdl compile script
//          .bmp               — decompressed textures
// ===========================================================================

#define NOMINMAX
#include <windows.h>
#include <ole2.h>
#include <gdiplus.h>
#pragma comment(lib, "gdiplus.lib")

#include "semodel_reader.h"
#include "seanim_reader.h"
#include "iwi_to_bmp.h"
#include "smd_writer.h"
#include "qc_writer.h"
#include "mesh_simplify.h"
#include "weapon_merge.h"

#include <iostream>
#include <fstream>
#include <filesystem>
#include <vector>
#include <string>
#include <map>
#include <set>
#include <cstring>
#include <algorithm>

namespace fs = std::filesystem;
using namespace Gdiplus;

// ===========================================================================
//  Helper functions
// ===========================================================================
static constexpr int MAX_TEX_RESOLUTION = 1024;

static bool ConvertImageToBMP(const std::string& src, const std::string& dst) {
    Bitmap* srcBmp = Bitmap::FromFile(std::wstring(src.begin(), src.end()).c_str());
    if (!srcBmp || srcBmp->GetLastStatus() != Ok) { delete srcBmp; return false; }
    int w = (int)srcBmp->GetWidth(), h = (int)srcBmp->GetHeight();
    if (w <= 0 || h <= 0) { delete srcBmp; return false; }
    Bitmap* bmp = srcBmp;
    if (w > MAX_TEX_RESOLUTION || h > MAX_TEX_RESOLUTION) {
        int nw = w, nh = h;
        if (nw > MAX_TEX_RESOLUTION) { nh = nh * MAX_TEX_RESOLUTION / nw; nw = MAX_TEX_RESOLUTION; }
        if (nh > MAX_TEX_RESOLUTION) { nw = nw * MAX_TEX_RESOLUTION / nh; nh = MAX_TEX_RESOLUTION; }
        std::cout << "    Resized " << w << "x" << h << " -> " << nw << "x" << nh << "\n";
        bmp = new Bitmap(nw, nh);
        Graphics g(bmp);
        g.SetInterpolationMode(InterpolationModeHighQualityBicubic);
        g.DrawImage(srcBmp, 0, 0, nw, nh);
        delete srcBmp;
        w = nw; h = nh;
    }
    Rect rct(0, 0, w, h);
    BitmapData bd;
    if (bmp->LockBits(&rct, ImageLockModeRead, PixelFormat32bppARGB, &bd) != Ok) { delete bmp; return false; }
    std::vector<uint8_t> rgba(w * h * 4);
    for (int y = 0; y < h; y++) {
        memcpy(&rgba[y * w * 4], (uint8_t*)bd.Scan0 + y * bd.Stride, w * 4);
    }
    bmp->UnlockBits(&bd);
    delete bmp;

    // Enhanced color quantization with popularity algorithm
    struct ColorCount { uint8_t r, g, b; int count; };
    std::map<int, ColorCount> freq;
    for (int i = 0; i < w * h; i++) {
        int key = ((rgba[i * 4] >> 3) << 10) | ((rgba[i * 4 + 1] >> 3) << 5) | (rgba[i * 4 + 2] >> 3);
        auto it = freq.find(key);
        if (it == freq.end()) {
            freq[key] = { rgba[i * 4], rgba[i * 4 + 1], rgba[i * 4 + 2], 1 };
        } else {
            it->second.count++;
            it->second.r = (uint8_t)((it->second.r * (it->second.count - 1) + rgba[i * 4]) / it->second.count);
            it->second.g = (uint8_t)((it->second.g * (it->second.count - 1) + rgba[i * 4 + 1]) / it->second.count);
            it->second.b = (uint8_t)((it->second.b * (it->second.count - 1) + rgba[i * 4 + 2]) / it->second.count);
        }
    }
    std::vector<ColorCount> pal;
    for (auto& kv : freq) pal.push_back(kv.second);
    std::sort(pal.begin(), pal.end(), [](auto& a, auto& b) { return a.count > b.count; });
    if ((int)pal.size() > 256) pal.resize(256);
    while ((int)pal.size() < 256) pal.push_back({ 0, 0, 0, 0 });

    // 32^3 color cube lookup table for O(1) nearest-color mapping
    std::vector<uint8_t> lut(32 * 32 * 32);
    for (int ri = 0; ri < 32; ri++) {
        for (int gi = 0; gi < 32; gi++) {
            for (int bi = 0; bi < 32; bi++) {
                int best = 0, bestDist = INT_MAX;
                int rr = (ri << 3) | (ri >> 2), gg = (gi << 3) | (gi >> 2), bb = (bi << 3) | (bi >> 2);
                for (int pi = 0; pi < 256; pi++) {
                    int dr = rr - pal[pi].r, dg = gg - pal[pi].g, db = bb - pal[pi].b;
                    int d = dr * dr + dg * dg + db * db;
                    if (d < bestDist) { bestDist = d; best = pi; }
                }
                lut[(ri << 10) | (gi << 5) | bi] = (uint8_t)best;
            }
        }
    }
    std::vector<uint8_t> idx(w * h);
    for (int i = 0; i < w * h; i++) {
        int ri = rgba[i * 4] >> 3, gi = rgba[i * 4 + 1] >> 3, bi = rgba[i * 4 + 2] >> 3;
        idx[i] = lut[(ri << 10) | (gi << 5) | bi];
    }

    // Write 8-bit BMP
    int stride = ((w + 3) / 4) * 4;
    uint32_t hdrSz = 14 + 40 + 256 * 4;
    uint32_t fileSz = hdrSz + stride * h;
    std::ofstream f(dst, std::ios::binary);
    if (!f) return false;
    auto w16 = [&](uint16_t v) { f.write((char*)&v, 2); };
    auto w32 = [&](uint32_t v) { f.write((char*)&v, 4); };
    f.write("BM", 2);
    w32(fileSz); w16(0); w16(0); w32(hdrSz);
    w32(40); w32((uint32_t)w); w32((uint32_t)h);
    w16(1); w16(8); w32(0); w32(stride * h);
    w32(2835); w32(2835); w32(256); w32(0);
    for (auto& c : pal) { f.put((char)c.b); f.put((char)c.g); f.put((char)c.r); f.put(0); }
    std::vector<uint8_t> row(stride, 0);
    for (int y = h - 1; y >= 0; y--) {
        for (int x = 0; x < w; x++) row[x] = idx[y * w + x];
        f.write((char*)row.data(), stride);
    }
    return true;
}

static std::string ToLower(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), ::tolower);
    return s;
}

static std::string SanitizeName(const std::string& s, int maxLen = 64) {
    std::string out = s;
    for (char& c : out)
        if (!std::isalnum((unsigned char)c) && c != '_' && c != '-' && c != '.' && c != '#' && c != '[' && c != ']' && c != '(' && c != ')' && c != ' ')
            c = '_';
    if ((int)out.size() > maxLen) out = out.substr(0, maxLen);
    return out;
}

static void PrintUsage(const char* prog) {
    std::cerr << "Usage: " << prog << " --model <file.semodel> [options]\n\n";
    std::cerr << "Options:\n";
    std::cerr << "  --model <file>       SEModel file (required)\n";
    std::cerr << "  --merge-model <f>    Secondary SEModel to merge (e.g. weapon)\n";
    std::cerr << "  --attach-bone <s>    Bone in primary to attach merge (default: tag_weapon_left)\n";
    std::cerr << "  --anim <file>        SEAnim file (optional, repeat for multiple)\n";
    std::cerr << "  --texdir <dir>       Textures directory containing .iwi files\n";
    std::cerr << "  --outdir <dir>       Output directory (default: ./<modelname>)\n";
    std::cerr << "  --scale <float>      Model scale factor (default: 1.0)\n";
    std::cerr << "  --lowpoly            Force low-poly mode (<=3500 tris)\n";
    std::cerr << "  --maxdetail          Maximum detail mode (minimal decimation)\n";
    std::cerr << "  --maxtris <int>      Custom triangle budget (implies low-poly mode)\n";
    std::cerr << "  --flipv              Flip texture V coordinate\n";
    std::cerr << "  --maxbones <int>     Maximum bones (default: 128)\n";
    std::cerr << "  --modeldir <path>    Model dir in QC $modelname (default: models/player)\n";
    std::cerr << "  --help               Show this help\n\n";
    std::cerr << "Examples:\n";
    std::cerr << "  " << prog << " --model model.semodel --texdir textures/ --outdir output/\n";
    std::cerr << "  " << prog << " --model char.semodel --anim walk.seanim --anim idle.seanim\n";
    std::cerr << "  " << prog << " --model arms.semodel --merge-model weapon.semodel --anim fire.seanim --maxdetail\n";
    std::cerr << "  " << prog << " --model hands.semodel --merge-model ak47.semodel --attach-bone tag_weapon_left\n";
}

// ===========================================================================
//  Convert WraithModel -> SmdScene (Enhanced)
// ===========================================================================
static SmdScene WraithModelToSmdScene(const WraithModel& wm, float scale = 1.0f, bool flipV = false) {
    SmdScene scene;
    scene.modelName = wm.AssetName;

    // Convert bones with enhanced information
    for (size_t i = 0; i < wm.Bones.size(); i++) {
        auto& wb = wm.Bones[i];
        SmdBone sb;
        sb.index = (int)i;
        sb.name = SanitizeName(wb.TagName, 32);
        sb.parent = wb.BoneParent;

        Vec3 localPos = { wb.LocalPosition.x, wb.LocalPosition.y, wb.LocalPosition.z };
        Quat localRot = wb.LocalRotation;
        Vec3 euler = localRot.ToEuler();

        sb.pos = { localPos.x * scale, localPos.y * scale, localPos.z * scale };
        sb.rot = euler;
        sb.originalLocalPos = sb.pos;
        sb.originalLocalRot = localRot;
        sb.isWeaponPart = (wb.WeaponPart != WeaponPartType::Unknown);
        sb.weaponPart = wb.WeaponPart;

        // Compute per-bone bounding box
        for (auto& mesh : wm.Submeshes) {
            for (auto& v : mesh.Vertices) {
                for (auto& w : v.Weights) {
                    if ((int)w.BoneIndex == i && w.Weight > 0.3f) {
                        Vec3 wp = { v.Position.x * scale, v.Position.y * scale, v.Position.z * scale };
                        if (!sb.bbox.valid) {
                            sb.bbox.mn = sb.bbox.mx = wp;
                            sb.bbox.valid = true;
                        } else {
                            sb.bbox.mn.x = std::min(sb.bbox.mn.x, wp.x);
                            sb.bbox.mn.y = std::min(sb.bbox.mn.y, wp.y);
                            sb.bbox.mn.z = std::min(sb.bbox.mn.z, wp.z);
                            sb.bbox.mx.x = std::max(sb.bbox.mx.x, wp.x);
                            sb.bbox.mx.y = std::max(sb.bbox.mx.y, wp.y);
                            sb.bbox.mx.z = std::max(sb.bbox.mx.z, wp.z);
                        }
                    }
                }
            }
        }

        scene.bones.push_back(sb);
    }

    // Dominant bone detection with weight quality check
    auto getDominantBone = [](const std::vector<WraithVertexWeight>& weights) -> int {
        if (weights.empty()) return 0;
        int bestBone = (int)weights[0].BoneIndex;
        float bestWeight = weights[0].Weight;
        for (auto& w : weights) {
            if (w.Weight > bestWeight) {
                bestWeight = w.Weight;
                bestBone = (int)w.BoneIndex;
            }
        }
        return bestBone;
    };

    // Material texture mapping
    std::map<int, std::string> materialTextures;
    for (size_t mi = 0; mi < wm.Materials.size(); mi++) {
        auto& mat = wm.Materials[mi];
        std::string texName = mat.DiffuseMapName;
        if (texName.empty()) texName = mat.MaterialName;
        if (texName.empty()) texName = "tex_" + std::to_string(mi);
        texName = QCWriter::TexStem(texName) + ".bmp";
        materialTextures[(int)mi] = texName;
    }

    // Enhanced winding detection per submesh
    int totalVerts = 0;
    std::vector<bool> flipSubmesh;
    for (size_t mi = 0; mi < wm.Submeshes.size(); mi++) {
        auto& mesh = wm.Submeshes[mi];
        int flipped = 0, total = 0;
        for (auto& face : mesh.Faces) {
            if (face.Index1 >= mesh.Vertices.size() || face.Index2 >= mesh.Vertices.size() || face.Index3 >= mesh.Vertices.size())
                continue;
            auto& v0 = mesh.Vertices[face.Index1];
            auto& v1 = mesh.Vertices[face.Index2];
            auto& v2 = mesh.Vertices[face.Index3];
            Vec3 e1 = { v1.Position.x - v0.Position.x, v1.Position.y - v0.Position.y, v1.Position.z - v0.Position.z };
            Vec3 e2 = { v2.Position.x - v0.Position.x, v2.Position.y - v0.Position.y, v2.Position.z - v0.Position.z };
            Vec3 fn = e1.cross(e2);
            double fnl = fn.len();
            if (fnl < 1e-10) continue;
            fn = fn.norm();
            Vec3 vn = { v0.Normal.x, v0.Normal.y, v0.Normal.z };
            double agree = vn.x * fn.x + vn.y * fn.y + vn.z * fn.z;
            if (agree < 0.0) flipped++;
            total++;
        }
        bool doFlip = (total > 0 && flipped > total / 2);
        flipSubmesh.push_back(doFlip);
        if (doFlip)
            std::cout << "  Submesh " << mi << ": inverted winding detected (" << flipped << "/" << total << ") — flipping\n";
    }

    // Convert triangles with enhanced UV handling
    size_t meshIdx = 0;
    for (auto& mesh : wm.Submeshes) {
        bool flip = (meshIdx < flipSubmesh.size()) ? flipSubmesh[meshIdx] : false;
        for (auto& face : mesh.Faces) {
            SmdTri tri;
            uint32_t idx[3] = { face.Index1, face.Index2, face.Index3 };
            if (flip) std::swap(idx[1], idx[2]);

            for (int i = 0; i < 3; i++) {
                const WraithVertex* v = &mesh.Vertices[idx[i]];

                tri.v[i].pos = { v->Position.x * scale, v->Position.y * scale, v->Position.z * scale };
                tri.v[i].nrm = { v->Normal.x, v->Normal.y, v->Normal.z };

                // Enhanced UV handling: use best available UV layer
                if (!v->UVLayers.empty()) {
                    // Use first UV layer with highest precision
                    tri.v[i].uv.u = v->UVLayers[0].u;
                    tri.v[i].uv.v = flipV ? 1.0 - v->UVLayers[0].v : v->UVLayers[0].v;

                    // Store additional UV layers if available
                    for (size_t uli = 1; uli < v->UVLayers.size(); uli++) {
                        tri.v[i].extraUVs.push_back({
                            v->UVLayers[uli].u,
                            flipV ? 1.0 - v->UVLayers[uli].v : v->UVLayers[uli].v
                        });
                    }
                }

                tri.v[i].bone = getDominantBone(v->Weights);
                for (auto& w : v->Weights)
                    tri.v[i].weights.push_back({ (int)w.BoneIndex, w.Weight });
            }

            // Enhanced material detection
            int matIdx = -1;
            if (!mesh.MaterialIndices.empty() && mesh.MaterialIndices[0] >= 0 &&
                mesh.MaterialIndices[0] < (int)wm.Materials.size()) {
                matIdx = mesh.MaterialIndices[0];
            }

            if (matIdx >= 0)
                tri.tex = materialTextures[matIdx];
            else
                tri.tex = "default.bmp";

            tri.materialIndex = matIdx;
            tri.originalMeshIndex = (int)meshIdx;
            tri.sourceMesh = wm.AssetName + "_mesh" + std::to_string(meshIdx);

            scene.tris.push_back(tri);
        }
        totalVerts += (int)mesh.Vertices.size();
        meshIdx++;
    }

    // Compute scene bounding box
    for (auto& t : scene.tris) {
        for (auto& v : t.v) {
            if (!scene.bbox.valid) {
                scene.bbox.mn = scene.bbox.mx = v.pos;
                scene.bbox.valid = true;
            } else {
                scene.bbox.mn.x = std::min(scene.bbox.mn.x, v.pos.x);
                scene.bbox.mn.y = std::min(scene.bbox.mn.y, v.pos.y);
                scene.bbox.mn.z = std::min(scene.bbox.mn.z, v.pos.z);
                scene.bbox.mx.x = std::max(scene.bbox.mx.x, v.pos.x);
                scene.bbox.mx.y = std::max(scene.bbox.mx.y, v.pos.y);
                scene.bbox.mx.z = std::max(scene.bbox.mx.z, v.pos.z);
            }
        }
    }

    return scene;
}

// ===========================================================================
//  Convert textures
// ===========================================================================
static int ConvertTextures(const std::string& texDir, const std::string& outDir) {
    int count = 0;
    if (!fs::exists(texDir)) {
        std::cerr << "Texture directory not found: " << texDir << "\n";
        return 0;
    }
    for (auto& entry : fs::directory_iterator(texDir)) {
        if (!entry.is_regular_file()) continue;
        auto ext = ToLower(entry.path().extension().string());
        if (ext != ".iwi") continue;
        std::string stem = entry.path().stem().string();
        std::string bmpPath = outDir + "/" + QCWriter::TexStem(stem) + ".bmp";
        if (fs::exists(bmpPath)) {
            std::cout << "  [SKIP] " << stem << ".bmp already exists\n";
            count++;
            continue;
        }
        std::cout << "  Converting IWI: " << entry.path().filename() << " -> " << fs::path(bmpPath).filename() << "\n";
        if (IWIToBMP::Convert(entry.path().string(), bmpPath)) {
            count++;
            std::cout << "    OK\n";
        } else {
            std::cerr << "    FAILED: " << entry.path() << "\n";
        }
    }
    return count;
}

static bool ConvertTexture(const std::string& iwiPath, const std::string& bmpPath) {
    std::cout << "  Converting IWI: " << fs::path(iwiPath).filename() << " -> " << fs::path(bmpPath).filename() << "\n";
    if (IWIToBMP::Convert(iwiPath, bmpPath)) {
        std::cout << "    OK\n";
        return true;
    }
    std::cerr << "    FAILED: " << iwiPath << "\n";
    return false;
}

// ===========================================================================
//  Main
// ===========================================================================
int main(int argc, char* argv[]) {
    // Initialize GDI+ for PNG->BMP conversion
    GdiplusStartupInput gdiplusStartupInput;
    ULONG_PTR gdiplusToken;
    GdiplusStartup(&gdiplusToken, &gdiplusStartupInput, NULL);

    std::string modelPath, texDir, outDir, modelDir = "models/player";
    std::string mergeModelPath, attachBone = "tag_weapon_left";
    std::vector<std::string> animPaths;
    float scale = 1.0f;
    bool lowPoly = false;
    bool flipV = false;
    bool maxDetail = false;
    int maxBones = 128;
    int maxTris = 0;
    std::vector<int> boneRemap;  // Bone index remap for overlimit bones
    std::set<std::string> animBoneDrop;  // Bones dropped during merge (animation data discarded)

    // Parse CLI
    for (int i = 1; i < argc; i++) {
        std::string arg = argv[i];
        if (arg == "--help" || arg == "-h") {
            PrintUsage(argv[0]);
            return 0;
        } else if (arg == "--model" && i + 1 < argc) {
            modelPath = argv[++i];
        } else if (arg == "--merge-model" && i + 1 < argc) {
            mergeModelPath = argv[++i];
        } else if (arg == "--attach-bone" && i + 1 < argc) {
            attachBone = argv[++i];
        } else if (arg == "--anim" && i + 1 < argc) {
            animPaths.push_back(argv[++i]);
        } else if (arg == "--texdir" && i + 1 < argc) {
            texDir = argv[++i];
        } else if (arg == "--outdir" && i + 1 < argc) {
            outDir = argv[++i];
        } else if (arg == "--scale" && i + 1 < argc) {
            scale = (float)std::atof(argv[++i]);
        } else if (arg == "--lowpoly") {
            lowPoly = true;
        } else if (arg == "--maxdetail") {
            maxDetail = true;
        } else if (arg == "--flipv") {
            flipV = true;
        } else if (arg == "--maxtris" && i + 1 < argc) {
            maxTris = std::atoi(argv[++i]);
        } else if (arg == "--maxbones" && i + 1 < argc) {
            maxBones = std::atoi(argv[++i]);
        } else if (arg == "--modeldir" && i + 1 < argc) {
            modelDir = argv[++i];
        } else {
            std::cerr << "Unknown option: " << arg << "\n";
            PrintUsage(argv[0]);
            return 1;
        }
    }

    if (modelPath.empty()) {
        std::cerr << "Error: --model is required\n";
        PrintUsage(argv[0]);
        return 1;
    }

    if (outDir.empty()) {
        fs::path mp(modelPath);
        outDir = mp.parent_path().string() + "/" + mp.stem().string();
    }
    fs::create_directories(outDir);

    std::string baseName = SanitizeName(fs::path(modelPath).stem().string(), 64);

    std::cout << "\n=== mw32smd v2.0 Enhanced — MW3 to GoldSrc Converter ===\n\n";
    std::cout << "Model:    " << modelPath << "\n";
    std::cout << "Output:   " << outDir << "\n";
    std::cout << "Scale:    " << scale << "\n";
    if (maxDetail) std::cout << "Mode:     MAXIMUM DETAIL\n";
    else if (lowPoly) std::cout << "Mode:     Low-poly\n";
    if (!texDir.empty()) std::cout << "Textures: " << texDir << "\n";
    if (!animPaths.empty()) {
        std::cout << "Anims:    ";
        for (auto& a : animPaths) std::cout << a << " ";
        std::cout << "\n";
    }
    if (!mergeModelPath.empty()) {
        std::cout << "Merge:    " << mergeModelPath << "\n";
        std::cout << "Attach:   " << attachBone << "\n";
    }
    std::cout << "\n";

    // ---- Step 1: Read SEModel ----
    std::cout << "--- Reading SEModel ---\n";
    WraithModel wm;
    {
        SEModelReader reader;
        if (!reader.Load(modelPath)) {
            std::cerr << "FAILED: Cannot load " << modelPath << "\n";
            return 1;
        }
        if (!reader.Read(wm)) {
            std::cerr << "FAILED: Cannot parse " << modelPath << "\n";
            return 1;
        }
        std::cout << "  Bones: " << wm.Bones.size() << "\n";
        std::cout << "  Submeshes: " << wm.Submeshes.size() << "\n";
        std::cout << "  Materials: " << wm.Materials.size() << "\n";
        int totalVerts = 0, totalFaces = 0;
        for (auto& m : wm.Submeshes) {
            totalVerts += (int)m.Vertices.size();
            totalFaces += (int)m.Faces.size();
        }
        std::cout << "  Total verts: " << totalVerts << "\n";
        std::cout << "  Total faces: " << totalFaces << "\n";

        // Show weapon parts detected in model
        int weaponParts = 0;
        for (auto& b : wm.Bones) {
            if (b.WeaponPart != WeaponPartType::Unknown) weaponParts++;
        }
        if (weaponParts > 0)
            std::cout << "  Weapon parts detected: " << weaponParts << "\n";
    }

    // ---- Step 1b: Enhanced Merge secondary model ----
    std::vector<WeaponPartInfo> mergedWeaponParts;
    if (!mergeModelPath.empty()) {
        std::cout << "\n--- Merging model: " << mergeModelPath << " ---\n";
        WraithModel wmMerge;
        {
            SEModelReader reader;
            if (!reader.Load(mergeModelPath)) {
                std::cerr << "FAILED: Cannot load " << mergeModelPath << "\n";
                return 1;
            }
            if (!reader.Read(wmMerge)) {
                std::cerr << "FAILED: Cannot parse " << mergeModelPath << "\n";
                return 1;
            }
            std::cout << "  Merge bones: " << wmMerge.Bones.size() << "\n";
            std::cout << "  Merge submeshes: " << wmMerge.Submeshes.size() << "\n";
            std::cout << "  Merge materials: " << wmMerge.Materials.size() << "\n";
        }

        if (WeaponMergeSystem::MergeWraithModels(wm, wmMerge, attachBone, scale, &mergedWeaponParts)) {
            std::cout << "  Merge OK — total bones: " << wm.Bones.size()
                      << ", submeshes: " << wm.Submeshes.size()
                      << ", materials: " << wm.Materials.size() << "\n";

            // Validate merge integrity
            std::string errors;
            if (!WeaponMergeSystem::ValidateMerge(wm, &errors)) {
                std::cerr << "  Merge validation warnings:\n" << errors << "\n";
            }

            // Remap bones that exceed the GoldSrc 64-bone limit
            if ((int)wm.Bones.size() > 64) {
                std::cout << "\n--- Remapping overlimit bones ---\n";
                std::map<std::string, std::string> mergedNameRemap;
                boneRemap = WeaponMergeSystem::RemapOverlimitBones(wm, 64, &mergedNameRemap);
                for (auto& [from, to] : mergedNameRemap)
                    animBoneDrop.insert(from);
                std::cout << "  Final bone count: " << wm.Bones.size() << "\n";
                std::cout << "  Dropped animation bones: " << animBoneDrop.size() << "\n";
            }
        } else {
            std::cerr << "FAILED: Model merge could not attach to bone \"" << attachBone << "\"\n";
            return 1;
        }
    }

    // ---- Step 2: Convert to SmdScene ----
    std::cout << "\n--- Converting to SMD scene ---\n";
    SmdScene scene = WraithModelToSmdScene(wm, scale, flipV);
    scene.isMergedWeapon = !mergeModelPath.empty();
    scene.attachBoneName = attachBone;
    scene.weaponParts = mergedWeaponParts;
    std::cout << "  Tris: " << scene.tris.size() << "\n";
    std::cout << "  Bones: " << scene.bones.size() << "\n";

    // ---- Step 3: Read SEAnim files ----
    std::vector<SmdAnim> smdAnims;
    for (auto& animPath : animPaths) {
        std::cout << "\n--- Reading SEAnim: " << animPath << " ---\n";
        WraithAnim wa;
        SEAnimReader animReader;
        if (!animReader.Load(animPath)) {
            std::cerr << "FAILED: Cannot load " << animPath << "\n";
            continue;
        }
        if (!animReader.Read(wa)) {
            std::cerr << "FAILED: Cannot parse " << animPath << "\n";
            continue;
        }
        std::cout << "  Frames: " << wa.FrameCount() << "\n";
        std::cout << "  Bones: " << wa.BoneCount() << "\n";
        std::cout << "  FPS: " << wa.FrameRate << "\n";
        std::cout << "  Type: " << (wa.AnimType == WraithAnimType::Absolute ? "Absolute" :
                                    wa.AnimType == WraithAnimType::Additive ? "Additive" :
                                    wa.AnimType == WraithAnimType::Relative ? "Relative" : "Delta") << "\n";

        // Print bone modifier info
        if (!wa.AnimationBoneModifiers.empty()) {
            std::cout << "  Bone modifiers:\n";
            for (auto& [bone, modType] : wa.AnimationBoneModifiers) {
                std::cout << "    " << bone << ": ";
                switch (modType) {
                    case WraithAnimType::Additive: std::cout << "Additive"; break;
                    case WraithAnimType::Relative: std::cout << "Relative"; break;
                    case WraithAnimType::Delta: std::cout << "Delta"; break;
                    default: std::cout << "Absolute"; break;
                }
                std::cout << "\n";
            }
        }

        // Print notetracks
        if (!wa.AnimationNotetracks.empty()) {
            std::cout << "  Notetracks:\n";
            for (auto& [note, frames] : wa.AnimationNotetracks) {
                std::cout << "    \"" << note << "\": frames ";
                for (size_t i = 0; i < frames.size() && i < 5; i++) {
                    if (i > 0) std::cout << ", ";
                    std::cout << frames[i];
                }
                if (frames.size() > 5) std::cout << " ... (" << frames.size() << " total)";
                std::cout << "\n";
            }
        }

        // ---- Apply bone remap to animation data ----
        if (!animBoneDrop.empty()) {
            WraithAnim remapped;
            remapped.AssetName = wa.AssetName;
            remapped.AnimType = wa.AnimType;
            remapped.Looping = wa.Looping;
            remapped.FrameRate = wa.FrameRate;
            remapped.AnimationNotetracks = wa.AnimationNotetracks;
            remapped.AnimationBoneModifiers = wa.AnimationBoneModifiers;

            int droppedCount = 0;

            // Remap position keys — DROP merged bones
            for (auto& [boneName, keys] : wa.AnimationPositionKeys) {
                if (animBoneDrop.count(boneName)) { droppedCount++; continue; }
                remapped.AnimationPositionKeys[boneName].insert(
                    remapped.AnimationPositionKeys[boneName].end(), keys.begin(), keys.end());
            }

            // Remap rotation keys — DROP merged bones
            for (auto& [boneName, keys] : wa.AnimationRotationKeys) {
                if (animBoneDrop.count(boneName)) { droppedCount++; continue; }
                remapped.AnimationRotationKeys[boneName].insert(
                    remapped.AnimationRotationKeys[boneName].end(), keys.begin(), keys.end());
            }

            // Remap scale keys — DROP merged bones
            for (auto& [boneName, keys] : wa.AnimationScaleKeys) {
                if (animBoneDrop.count(boneName)) { droppedCount++; continue; }
                remapped.AnimationScaleKeys[boneName].insert(
                    remapped.AnimationScaleKeys[boneName].end(), keys.begin(), keys.end());
            }

            // Remap bone modifiers — DROP merged bones
            for (auto& [boneName, modType] : wa.AnimationBoneModifiers) {
                if (animBoneDrop.count(boneName)) continue;
                remapped.AnimationBoneModifiers[boneName] = modType;
            }

            wa = remapped;
            std::cout << "  Dropped " << droppedCount << " merged bone animation channels\n";
        }

        // ---- Validate bone matching ----
        std::map<std::string, int> animBones;
        for (auto& [k, v] : wa.AnimationPositionKeys) animBones[k] += (int)v.size();
        for (auto& [k, v] : wa.AnimationRotationKeys) animBones[k] += (int)v.size();

        int matchedBones = 0, unmatchedBones = 0;
        bool hasRootBone = false;
        static const char* rootNames[] = { "tag_origin", "j_mainroot", "root", "Bip01", "j_hips" };
        for (auto& [boneName, keyCount] : animBones) {
            bool found = false;
            for (auto& b : scene.bones) {
                if (b.name == boneName) { found = true; break; }
            }
            if (found) {
                matchedBones++;
                for (auto& rn : rootNames)
                    if (boneName == rn) hasRootBone = true;
            } else {
                unmatchedBones++;
            }
        }
        int totalAnimBones = matchedBones + unmatchedBones;
        float matchPct = (totalAnimBones > 0) ? (100.0f * matchedBones / totalAnimBones) : 0.0f;

        std::cout << "  Bone match: " << matchedBones << "/" << totalAnimBones
                  << " (" << (int)matchPct << "%)\n";

        // Show top unmatched bones
        std::vector<std::pair<int, std::string>> sorted;
        for (auto& [k, v] : animBones) {
            bool inModel = false;
            for (auto& b : scene.bones) if (b.name == k) { inModel = true; break; }
            if (!inModel) sorted.push_back({ v, k });
        }
        std::sort(sorted.begin(), sorted.end(), [](auto& a, auto& b) { return a.first > b.first; });
        for (int i = 0; i < std::min(5, (int)sorted.size()); i++)
            std::cout << "    [UNMATCHED] \"" << sorted[i].second << "\": " << sorted[i].first << " keys\n";
        if ((int)sorted.size() > 5)
            std::cout << "    ... and " << (int)sorted.size() - 5 << " more unmatched bones\n";

        // ---- Validate animation type for GoldSrc ----
        bool animTypeOk = true;
        if (wa.AnimType == WraithAnimType::Additive) {
            std::cerr << "  WARNING: Additive animation not supported in GoldSrc — will be treated as Absolute\n";
            animTypeOk = false;
        } else if (wa.AnimType == WraithAnimType::Relative) {
            std::cerr << "  WARNING: Relative animation not supported in GoldSrc — will be treated as Absolute\n";
            animTypeOk = false;
        } else if (wa.AnimType == WraithAnimType::Delta) {
            std::cerr << "  WARNING: Delta animation not supported in GoldSrc — will be treated as Absolute\n";
            animTypeOk = false;
        }

        // ---- Validate bone modifiers ----
        for (auto& [bone, modType] : wa.AnimationBoneModifiers) {
            if (modType == WraithAnimType::Additive || modType == WraithAnimType::Relative || modType == WraithAnimType::Delta) {
                std::cerr << "  WARNING: Bone modifier on \"" << bone << "\" is non-absolute — may not work in GoldSrc\n";
            }
        }

        // ---- Final validation: reject or accept ----
        bool reject = false;
        if (matchedBones == 0) {
            std::cerr << "  REJECTED: Zero bones match the model — wrong skeleton?\n";
            reject = true;
        } else if (matchPct < 50.0f) {
            std::cerr << "  REJECTED: Only " << (int)matchPct << "% of bones match (<50% threshold) — likely wrong skeleton\n";
            reject = true;
        } else if (!hasRootBone) {
            std::cerr << "  WARNING: No root bone (tag_origin/j_mainroot/root) found in animation\n";
        }

        if (matchPct >= 80.0f) {
            std::cout << "  Validation: PASS — good skeleton match\n";
        } else if (matchPct >= 20.0f) {
            std::cout << "  Validation: WARN — partial skeleton match, animation may look wrong\n";
        }

        if (reject) {
            std::cerr << "  SKIPPING animation: " << animPath << "\n";
            continue;
        }

        SmdAnim sa = SMDWriter::ConvertAnim(wa, scene);
        sa.name = fs::path(animPath).stem().string();
        smdAnims.push_back(sa);
        std::cout << "  ACCEPTED: " << sa.name << " (" << sa.frames << " frames)\n";
    }

    // ---- Step 4: Convert textures ----
    std::vector<std::string> convertedTextures;
    std::set<std::string> texSet;
    if (!texDir.empty()) {
        std::cout << "\n--- Converting textures ---\n";
        for (auto& mat : wm.Materials) {
            std::string texName = mat.DiffuseMapName;
            if (texName.empty()) texName = mat.MaterialName;
            if (texName.empty()) continue;
            std::string stem = QCWriter::TexStem(texName);
            std::string bmpPath = outDir + "/" + stem + ".bmp";

            bool found = false;
            if (fs::exists(texDir)) {
                for (auto& entry : fs::recursive_directory_iterator(texDir)) {
                    if (!entry.is_regular_file()) continue;
                    auto fstem = ToLower(entry.path().stem().string());
                    if (fstem == ToLower(stem)) {
                        auto ext = ToLower(entry.path().extension().string());
                        if (ext == ".iwi") {
                            if (!fs::exists(bmpPath))
                                if (ConvertTexture(entry.path().string(), bmpPath))
                                    convertedTextures.push_back(bmpPath);
                        } else if (ext == ".png" || ext == ".tga" || ext == ".jpg") {
                            if (!fs::exists(bmpPath)) {
                                std::cout << "  Converting: " << entry.path().filename() << " -> " << stem << ".bmp\n";
                                ConvertImageToBMP(entry.path().string(), bmpPath);
                            }
                        }
                        texSet.insert(stem + ".bmp");
                        found = true;
                        break;
                    }
                }
            }
            if (!found) {
                texSet.insert(stem + ".bmp");
            }
        }

        if (fs::exists(texDir)) {
            for (auto& entry : fs::recursive_directory_iterator(texDir)) {
                if (!entry.is_regular_file()) continue;
                auto ext = ToLower(entry.path().extension().string());
                if (ext != ".iwi" && ext != ".png" && ext != ".tga" && ext != ".jpg") continue;
                std::string stem = QCWriter::TexStem(entry.path().stem().string());
                std::string bmpName = stem + ".bmp";
                if (texSet.find(bmpName) == texSet.end()) continue;
                std::string bmpPath = outDir + "/" + bmpName;
                if (fs::exists(bmpPath)) continue;
                if (ext == ".iwi") {
                    if (ConvertTexture(entry.path().string(), bmpPath))
                        convertedTextures.push_back(bmpPath);
                } else if (ext == ".png" || ext == ".tga" || ext == ".jpg") {
                    std::cout << "  Converting: " << entry.path().filename() << " -> " << bmpName << "\n";
                    ConvertImageToBMP(entry.path().string(), bmpPath);
                }
            }
        }
    }

    for (auto& t : scene.tris) {
        if (!t.tex.empty()) texSet.insert(t.tex);
    }

    // ---- Step 5: Run GoldSrc Optimizer ----
    std::cout << "\n=== Running GoldSrc Optimizer ===\n";
    GSOptimizer opt;
    if (maxTris > 0) {
        opt.Run(scene, maxBones, true, maxTris, maxDetail);
    } else {
        opt.Run(scene, maxBones, lowPoly, 3500, maxDetail);
    }

    // ---- Step 6: Write SMD files ----
    std::cout << "\n--- Writing SMD files ---\n";
    std::vector<std::string> bodyNames;
    std::string refSMDName = baseName + "_ref";

    if (scene.bodyBins.empty()) {
        std::string smdPath = outDir + "/" + refSMDName + ".smd";
        if (SMDWriter::WriteRefSMD(smdPath, scene)) {
            std::cout << "  Written: " << smdPath << "\n";
        } else {
            std::cerr << "  FAILED: " << smdPath << "\n";
        }
        bodyNames.push_back(refSMDName);
    } else {
        for (size_t bi = 0; bi < scene.bodyBins.size(); bi++) {
            SmdScene bodyScene;
            bodyScene.bones = scene.bones;
            bodyScene.tris = scene.bodyBins[bi];
            bodyScene.bbox = scene.bbox;

            std::string bodyName = baseName + "_body" + std::to_string(bi);
            std::string smdPath = outDir + "/" + bodyName + ".smd";

            if (SMDWriter::WriteRefSMD(smdPath, bodyScene)) {
                std::cout << "  Written: " << smdPath << "\n";
            } else {
                std::cerr << "  FAILED: " << smdPath << "\n";
            }
            bodyNames.push_back(bodyName);
        }
        std::string smdPath = outDir + "/" + refSMDName + ".smd";
        SMDWriter::WriteRefSMD(smdPath, scene);
    }

    // ---- Step 7: Write animation SMD files ----
    if (smdAnims.empty()) {
        SmdAnim idle;
        idle.name = "idle";
        idle.fps = 30;
        idle.frames = 1;
        idle.loop = true;
        idle.data.resize(1);
        idle.data[0].resize(scene.bones.size());
        for (size_t bi = 0; bi < scene.bones.size(); bi++) {
            idle.data[0][bi].pos = scene.bones[bi].pos;
            idle.data[0][bi].rot = scene.bones[bi].rot;
        }
        smdAnims.push_back(idle);
    }
    for (auto& sa : smdAnims) {
        std::string stem = sa.name;
        auto dotPos = stem.find_last_of('.');
        if (dotPos != std::string::npos) stem = stem.substr(0, dotPos);
        std::string animName = QCWriter::SanitizeName(stem, 64);
        std::string animPath = outDir + "/" + animName + ".smd";
        if (SMDWriter::WriteAnimSMD(animPath, scene, sa)) {
            std::cout << "  Written anim: " << animPath << " (" << sa.frames << " frames @ " << (int)sa.fps << " fps)\n";
        } else {
            std::cerr << "  FAILED anim: " << animPath << "\n";
        }
    }

    // ---- Step 8: Write QC file ----
    std::cout << "\n--- Writing QC file ---\n";
    std::string qcPath = outDir + "/" + baseName + ".qc";
    if (QCWriter::WriteQC(qcPath, baseName, scene, bodyNames, smdAnims, texSet, modelDir)) {
        std::cout << "  Written: " << qcPath << "\n";
    } else {
        std::cerr << "  FAILED: " << qcPath << "\n";
    }

    GdiplusShutdown(gdiplusToken);

    std::cout << "\n=== Conversion complete! ===\n";
    std::cout << "Output directory: " << outDir << "\n";
    std::cout << "Compile with: studiomdl.exe " << outDir << "/" << baseName << ".qc\n\n";

    return 0;
}
