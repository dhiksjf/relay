#pragma once
#include <cstdint>
#include <string>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <algorithm>
#include <cmath>

// ===========================================================================
//  Enhanced Math Types — Improved precision for UV and position data
// ===========================================================================
struct Vec2 {
    double u = 0, v = 0;
    Vec2() = default;
    Vec2(double u_, double v_) : u(u_), v(v_) {}
};

struct Vec3 {
    double x = 0, y = 0, z = 0;
    Vec3() = default;
    Vec3(double x_, double y_, double z_) : x(x_), y(y_), z(z_) {}
    Vec3 operator+(const Vec3& o) const { return { x + o.x, y + o.y, z + o.z }; }
    Vec3 operator-(const Vec3& o) const { return { x - o.x, y - o.y, z - o.z }; }
    Vec3 operator*(double s) const { return { x * s, y * s, z * s }; }
    Vec3 operator-() const { return { -x, -y, -z }; }
    double dot(const Vec3& o) const { return x * o.x + y * o.y + z * o.z; }
    Vec3 cross(const Vec3& o) const { return { y * o.z - z * o.y, z * o.x - x * o.z, x * o.y - y * o.x }; }
    double lenSq() const { return x * x + y * y + z * z; }
    double len() const { return std::sqrt(lenSq()); }
    Vec3 norm() const { double l = len(); return l < 1e-10 ? Vec3{ 0,0,1 } : Vec3{ x / l, y / l, z / l }; }
    bool zero() const { return lenSq() < 1e-12; }
    bool operator==(const Vec3& o) const { return std::abs(x - o.x) < 1e-5 && std::abs(y - o.y) < 1e-5 && std::abs(z - o.z) < 1e-5; }
};

struct Quat {
    double x = 0, y = 0, z = 0, w = 1;
    Quat() = default;
    Quat(double x_, double y_, double z_, double w_) : x(x_), y(y_), z(z_), w(w_) {}

    // Improved ToEuler with gimbal lock detection
    Vec3 ToEuler() const {
        double n = std::sqrt(x * x + y * y + z * z + w * w);
        if (n < 1e-10) return {};
        double qx = x / n, qy = y / n, qz = z / n, qw = w / n;

        // Roll (X-axis rotation)
        double sr = 2 * (qw * qx + qy * qz);
        double cr = 1 - 2 * (qx * qx + qy * qy);
        double rx = std::atan2(sr, cr);

        // Pitch (Y-axis rotation) - with gimbal lock detection
        double sp = 2 * (qw * qy - qz * qx);
        double ry;
        if (std::abs(sp) >= 0.999999) {
            // Gimbal lock case
            ry = std::copysign(3.14159265358979323846 / 2.0, sp);
            // Reset roll to 0 when gimbal locked
            rx = 0;
        } else {
            ry = std::asin(std::clamp(sp, -1.0, 1.0));
        }

        // Yaw (Z-axis rotation)
        double sy = 2 * (qw * qz + qx * qy);
        double cy = 1 - 2 * (qy * qy + qz * qz);
        double rz = std::atan2(sy, cy);

        return { rx, ry, rz };
    }

    static Quat FromEuler(double rx, double ry, double rz) {
        double cx = std::cos(rx * 0.5), sx = std::sin(rx * 0.5);
        double cy = std::cos(ry * 0.5), sy = std::sin(ry * 0.5);
        double cz = std::cos(rz * 0.5), sz = std::sin(rz * 0.5);
        return {
            sx * cy * cz - cx * sy * sz,
            cx * sy * cz + sx * cy * sz,
            cx * cy * sz - sx * sy * cz,
            cx * cy * cz + sx * sy * sz
        };
    }

    Quat operator*(const Quat& o) const {
        return {
            w * o.x + x * o.w + y * o.z - z * o.y,
            w * o.y - x * o.z + y * o.w + z * o.x,
            w * o.z + x * o.y - y * o.x + z * o.w,
            w * o.w - x * o.x - y * o.y - z * o.z
        };
    }

    Quat Conjugate() const { return { -x, -y, -z, w }; }

    // SLERP interpolation between two quaternions
    static Quat Slerp(const Quat& a, const Quat& b, double t) {
        double dot = a.x * b.x + a.y * b.y + a.z * b.z + a.w * b.w;
        Quat b2 = b;
        if (dot < 0) { b2 = { -b.x, -b.y, -b.z, -b.w }; dot = -dot; }
        if (dot > 0.9995) {
            // Linear interpolation for very close quaternions
            return Quat{
                a.x + t * (b2.x - a.x),
                a.y + t * (b2.y - a.y),
                a.z + t * (b2.z - a.z),
                a.w + t * (b2.w - a.w)
            }.Normalized();
        }
        double theta0 = std::acos(dot);
        double theta = theta0 * t;
        double sinTheta = std::sin(theta);
        double sinTheta0 = std::sin(theta0);
        double s0 = std::cos(theta) - dot * sinTheta / sinTheta0;
        double s1 = sinTheta / sinTheta0;
        return {
            a.x * s0 + b2.x * s1,
            a.y * s0 + b2.y * s1,
            a.z * s0 + b2.z * s1,
            a.w * s0 + b2.w * s1
        };
    }

    Quat Normalized() const {
        double n = std::sqrt(x * x + y * y + z * z + w * w);
        if (n < 1e-10) return Quat{ 0, 0, 0, 1 };
        return { x / n, y / n, z / n, w / n };
    }
};

struct BoneWeight { int bone; float weight; };

// ===========================================================================
//  Weapon Part Attachment Types — for intelligent weapon merging
// ===========================================================================
enum class WeaponPartType {
    Unknown,
    Body,           // Main weapon body
    Magazine,       // Magazine/clip
    MagazineEmpty,  // Empty magazine
    Bolt,           // Bolt/slide
    Barrel,         // Barrel
    Stock,          // Stock/buttstock
    Grip,           // Foregrip
    Scope,          // Optical sight
    IronSight,      // Iron sights
    Muzzle,         // Muzzle brake/flash hider
    Laser,          // Laser attachment
    GrenadeLauncher,// Under-barrel grenade launcher
    Bipod,          // Bipod
    Trigger,        // Trigger group
    Receiver,       // Receiver/frame
    Slide,          // Pistol slide
    Cylinder,       // Revolver cylinder
    Pump,           // Shotgun pump
    CarryHandle,    // Carry handle
    Silencer,       // Suppressor/silencer
    AmmoBelt,       // Machine gun ammo belt
    ChargingHandle, // Charging handle
    Safety,         // Safety selector
    CaseEjector     // Shell ejection port
};

struct WeaponPartInfo {
    std::string boneName;
    WeaponPartType partType;
    int originalBoneIndex;
    int parentBoneIndex;  // In the merged skeleton
};

// ===========================================================================
//  SMD internal types (Enhanced with full weight support and UV precision)
// ===========================================================================
struct SmdVert {
    Vec3 pos, nrm;
    Vec2 uv;
    int bone = 0;
    std::vector<BoneWeight> weights;
    // Additional UV layers for Source Engine (if needed)
    std::vector<Vec2> extraUVs;
};

struct SmdTri {
    SmdVert v[3];
    std::string tex;
    std::string sourceMesh;
    int originalMeshIndex = 0;
    int materialIndex = 0;
};

struct SmdBone {
    int index = -1;
    std::string name;
    int parent = -1;
    Vec3 pos;
    Vec3 rot;
    struct { Vec3 mn, mx; bool valid = false; } bbox;
    // Original transform for merge operations
    Vec3 originalLocalPos;
    Quat originalLocalRot;
    bool isWeaponPart = false;
    WeaponPartType weaponPart = WeaponPartType::Unknown;
};

enum class WraithAnimType : uint8_t {
    Absolute = 0, Additive = 1, Relative = 2, Delta = 3
};

struct SmdAnim {
    std::string name;
    int frames = 0;
    float fps = 30.0f;
    bool loop = false;
    // Animation type for proper blending
    WraithAnimType animType = WraithAnimType::Absolute;
    struct Frame { Vec3 pos, rot; };
    std::vector<std::vector<Frame>> data; // [frame][bone]
    // Notetracks for weapon timing
    std::unordered_map<std::string, std::vector<int>> notetracks;
};

struct SmdScene {
    std::vector<SmdBone> bones;
    std::vector<SmdTri>  tris;
    std::vector<SmdAnim> anims;
    struct { Vec3 mn, mx; bool valid = false; } bbox;
    std::vector<std::vector<SmdTri>> bodyBins;
    std::string modelName;
    // Weapon merge info
    std::vector<WeaponPartInfo> weaponParts;
    bool isMergedWeapon = false;
    std::string attachBoneName;
};

// ===========================================================================
//  Wraith types (for SEModel/SEAnim parsing) — Enhanced
// ===========================================================================
struct WraithVertexWeight {
    uint32_t BoneIndex = 0;
    float Weight = 0;
};

struct WraithVertex {
    Vec3 Position;
    Vec3 Normal;
    std::vector<Vec2> UVLayers;
    uint8_t Color[4] = { 255,255,255,255 };
    std::vector<WraithVertexWeight> Weights;
    // Full weight list preserved for maximum quality
    std::vector<WraithVertexWeight> FullWeights;
};

struct WraithFace {
    uint32_t Index1, Index2, Index3;
};

struct WraithSubmesh {
    std::vector<WraithVertex> Vertices;
    std::vector<WraithFace> Faces;
    std::vector<int32_t> MaterialIndices;
    std::string MeshName;  // For better tracking
};

struct WraithMaterial {
    std::string MaterialName;
    std::string DiffuseMapName;
    std::string NormalMapName;
    std::string SpecularMapName;
    // Additional material properties
    float Glossiness = 0.5f;
    float Opacity = 1.0f;
    bool HasAlpha = false;
    bool IsEmissive = false;
};

struct WraithBone {
    std::string TagName;
    int32_t BoneParent = -1;
    Vec3 LocalPosition;
    Quat LocalRotation;
    Vec3 GlobalPosition;
    Quat GlobalRotation;
    Vec3 BoneScale{ 1,1,1 };
    // Flags for weapon parts
    bool IsWeaponRoot = false;
    WeaponPartType WeaponPart = WeaponPartType::Unknown;
};

struct WraithModel {
    std::string AssetName;
    std::vector<WraithBone> Bones;
    std::vector<WraithSubmesh> Submeshes;
    std::vector<WraithMaterial> Materials;
    std::vector<std::string> BlendShapes;
};

template<class T> struct WraithAnimFrame {
    uint32_t Frame;
    T Value;
};

struct WraithAnim {
    std::string AssetName;
    WraithAnimType AnimType = WraithAnimType::Absolute;
    bool Looping = false;
    float FrameRate = 30.0f;
    std::unordered_map<std::string, std::vector<WraithAnimFrame<Vec3>>> AnimationPositionKeys;
    std::unordered_map<std::string, std::vector<WraithAnimFrame<Quat>>> AnimationRotationKeys;
    std::unordered_map<std::string, std::vector<WraithAnimFrame<Vec3>>> AnimationScaleKeys;
    std::unordered_map<std::string, std::vector<uint32_t>> AnimationNotetracks;
    std::unordered_map<std::string, WraithAnimType> AnimationBoneModifiers;

    uint32_t FrameCount() const {
        uint32_t maxF = 0;
        for (auto& [k, v] : AnimationPositionKeys)
            for (auto& f : v) if (f.Frame > maxF) maxF = f.Frame;
        for (auto& [k, v] : AnimationRotationKeys)
            for (auto& f : v) if (f.Frame > maxF) maxF = f.Frame;
        for (auto& [k, v] : AnimationScaleKeys)
            for (auto& f : v) if (f.Frame > maxF) maxF = f.Frame;
        return maxF + 1;
    }
    uint32_t BoneCount() const {
        std::unordered_set<std::string> all;
        for (auto& [k, v] : AnimationPositionKeys) all.insert(k);
        for (auto& [k, v] : AnimationRotationKeys) all.insert(k);
        for (auto& [k, v] : AnimationScaleKeys) all.insert(k);
        return (uint32_t)all.size();
    }
    std::unordered_set<std::string> Bones() const {
        std::unordered_set<std::string> all;
        for (auto& [k, v] : AnimationPositionKeys) all.insert(k);
        for (auto& [k, v] : AnimationRotationKeys) all.insert(k);
        for (auto& [k, v] : AnimationScaleKeys) all.insert(k);
        return all;
    }
    uint32_t NotificationCount() const {
        uint32_t n = 0;
        for (auto& [k, v] : AnimationNotetracks) n += (uint32_t)v.size();
        return n;
    }
};

// ===========================================================================
//  IWI → DDS types
// ===========================================================================
struct XImageDDS {
    int8_t* DataBuffer = nullptr;
    uint32_t DataSize = 0;
    ~XImageDDS() { delete[] DataBuffer; }
    XImageDDS() = default;
    XImageDDS(const XImageDDS&) = delete;
    XImageDDS& operator=(const XImageDDS&) = delete;
    XImageDDS(XImageDDS&& o) noexcept : DataBuffer(o.DataBuffer), DataSize(o.DataSize) { o.DataBuffer = nullptr; o.DataSize = 0; }
    XImageDDS& operator=(XImageDDS&& o) noexcept { std::swap(DataBuffer, o.DataBuffer); std::swap(DataSize, o.DataSize); return *this; }
};

// ===========================================================================
//  Utility: Weapon part detection from bone name
// ===========================================================================
inline WeaponPartType DetectWeaponPartType(const std::string& boneName) {
    std::string lo = boneName;
    std::transform(lo.begin(), lo.end(), lo.begin(), ::tolower);

    // Magazine/Clip detection
    if (lo.find("mag") != std::string::npos || lo.find("clip") != std::string::npos) {
        if (lo.find("empty") != std::string::npos) return WeaponPartType::MagazineEmpty;
        return WeaponPartType::Magazine;
    }

    // Bolt/Slide
    if (lo.find("bolt") != std::string::npos) return WeaponPartType::Bolt;
    if (lo.find("slide") != std::string::npos) return WeaponPartType::Slide;

    // Barrel
    if (lo.find("barrel") != std::string::npos) return WeaponPartType::Barrel;

    // Stock
    if (lo.find("stock") != std::string::npos || lo.find("butt") != std::string::npos)
        return WeaponPartType::Stock;

    // Grip
    if (lo.find("grip") != std::string::npos && lo.find("fore") != std::string::npos)
        return WeaponPartType::Grip;

    // Scope
    if (lo.find("scope") != std::string::npos || lo.find("optic") != std::string::npos ||
        lo.find("acog") != std::string::npos || lo.find("redot") != std::string::npos ||
        lo.find("holo") != std::string::npos)
        return WeaponPartType::Scope;

    // Iron sight
    if (lo.find("sight") != std::string::npos && lo.find("scope") == std::string::npos)
        return WeaponPartType::IronSight;

    // Muzzle
    if (lo.find("muzzle") != std::string::npos || lo.find("flash") != std::string::npos ||
        lo.find("brake") != std::string::npos)
        return WeaponPartType::Muzzle;

    // Laser
    if (lo.find("laser") != std::string::npos) return WeaponPartType::Laser;

    // Grenade launcher
    if (lo.find("gl") != std::string::npos || lo.find("launcher") != std::string::npos)
        return WeaponPartType::GrenadeLauncher;

    // Bipod
    if (lo.find("bipod") != std::string::npos) return WeaponPartType::Bipod;

    // Trigger
    if (lo.find("trigger") != std::string::npos) return WeaponPartType::Trigger;

    // Receiver
    if (lo.find("receiver") != std::string::npos || lo.find("upper") != std::string::npos ||
        lo.find("lower") != std::string::npos)
        return WeaponPartType::Receiver;

    // Cylinder
    if (lo.find("cylinder") != std::string::npos) return WeaponPartType::Cylinder;

    // Pump
    if (lo.find("pump") != std::string::npos) return WeaponPartType::Pump;

    // Carry handle
    if (lo.find("carry") != std::string::npos) return WeaponPartType::CarryHandle;

    // Silencer
    if (lo.find("silencer") != std::string::npos || lo.find("suppress") != std::string::npos)
        return WeaponPartType::Silencer;

    // Ammo belt
    if (lo.find("belt") != std::string::npos) return WeaponPartType::AmmoBelt;

    // Charging handle
    if (lo.find("charge") != std::string::npos || lo.find("cock") != std::string::npos)
        return WeaponPartType::ChargingHandle;

    // Safety
    if (lo.find("safety") != std::string::npos || lo.find("select") != std::string::npos)
        return WeaponPartType::Safety;

    // Case ejector
    if (lo.find("eject") != std::string::npos || lo.find("port") != std::string::npos)
        return WeaponPartType::CaseEjector;

    // If it contains "weapon" but no specific part, it's the body
    if (lo.find("weapon") != std::string::npos || lo.find("gun") != std::string::npos ||
        lo.find("wpn") != std::string::npos || lo.find("rifle") != std::string::npos ||
        lo.find("pistol") != std::string::npos)
        return WeaponPartType::Body;

    return WeaponPartType::Unknown;
}

// ===========================================================================
//  Utility: Get attachment point names for weapon merging
// ===========================================================================
inline std::vector<std::string> GetWeaponAttachmentBones() {
    return {
        "tag_weapon_left",
        "tag_weapon_right",
        "tag_weapon",
        "tag_weapon2",
        "tag_sling",
        "tag_sling_left",
        "tag_sling_right",
        "tag_clip",
        "tag_magazine",
        "tag_barrel",
        "tag_stock",
        "tag_grip",
        "tag_scope",
        "tag_muzzle",
        "tag_flash",
        "tag_laser",
        "tag_akimbo",
        "tag_butt"
    };
}

// ===========================================================================
//  Utility: Detect if a bone is a tag/attachment point
// ===========================================================================
inline bool IsTagBone(const std::string& boneName) {
    std::string lo = boneName;
    std::transform(lo.begin(), lo.end(), lo.begin(), ::tolower);
    return lo.find("tag_") == 0;
}
