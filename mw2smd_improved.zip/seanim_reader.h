#pragma once
#include "wraith_types.h"
#include <fstream>
#include <cstring>

// ===========================================================================
//  SEAnim binary reader — Enhanced with full feature support
//  Spec: magic "SEAnim" (6 bytes), version 1, header size 0x1C
//  Improvements:
//    - Bone modifier support (Additive/Relative/Delta)
//    - Notetrack extraction for weapon timing
//    - Scale key support
//    - Better frame interpolation data
// ===========================================================================
struct SEAnimReader {
    std::vector<uint8_t> buf;
    size_t pos = 0;

    bool Load(const std::string& path) {
        std::ifstream f(path, std::ios::binary | std::ios::ate);
        if (!f) return false;
        size_t sz = (size_t)f.tellg();
        f.seekg(0);
        buf.resize(sz);
        f.read((char*)buf.data(), sz);
        return !f.fail();
    }

    bool ReadHeader() {
        if (buf.size() < 6 + 2 + 2 + 1 + 1 + 1 + 1 + 2 + 4 + 4 + 4 + 1 + 3 + 4)
            return false;
        if (memcmp(buf.data(), "SEAnim", 6) != 0) return false;
        pos = 6;
        version = ReadU16();
        if (version != 1) return false;
        headerSize = ReadU16();
        animTypeRaw = ReadU8();
        flags = ReadU8();
        dataPresent = ReadU8();
        dataProperties = ReadU8();
        pos += 2; // reserved
        frameRate = ReadF32();
        frameCount = ReadU32();
        boneCount = ReadU32();
        modifierCount = ReadU8();
        pos += 3; // reserved
        notificationCount = ReadU32();
        hasPos  = (dataPresent & 1) != 0;
        hasRot  = (dataPresent & 2) != 0;
        hasScale = (dataPresent & 4) != 0;
        hasNotes = (dataPresent & 0x40) != 0;
        looping = (flags & 1) != 0;
        switch (animTypeRaw) {
            case 0: animType = WraithAnimType::Absolute; break;
            case 1: animType = WraithAnimType::Additive; break;
            case 2: animType = WraithAnimType::Relative; break;
            case 3: animType = WraithAnimType::Delta; break;
            default: animType = WraithAnimType::Absolute; break;
        }
        return true;
    }

    bool Read(WraithAnim& anim) {
        if (!ReadHeader()) return false;

        anim.AnimType = animType;
        anim.Looping = looping;
        anim.FrameRate = frameRate;

        // Read bone tags
        std::vector<std::string> boneTags(boneCount);
        for (uint32_t i = 0; i < boneCount; i++)
            boneTags[i] = ReadString();

        // Read modifiers — IMPORTANT for proper animation blending
        for (uint8_t i = 0; i < modifierCount; i++) {
            int idx;
            if (boneCount <= 0xFF) idx = ReadU8();
            else idx = ReadU16();
            uint8_t modType = ReadU8();
            WraithAnimType wt;
            switch (modType) {
                case 0: wt = WraithAnimType::Absolute; break;
                case 1: wt = WraithAnimType::Additive; break;
                case 2: wt = WraithAnimType::Relative; break;
                case 3: wt = WraithAnimType::Delta; break;
                default: wt = WraithAnimType::Absolute; break;
            }
            if (idx >= 0 && idx < (int)boneTags.size())
                anim.AnimationBoneModifiers[boneTags[idx]] = wt;
        }

        // Read key data per bone
        for (uint32_t bi = 0; bi < boneCount; bi++) {
            const std::string& boneName = boneTags[bi];
            ReadU8(); // bone flags (unused)

            // Position keys
            if (hasPos) {
                uint32_t keyCount = ReadKeyCount();
                for (uint32_t k = 0; k < keyCount; k++) {
                    uint32_t frame = ReadFrameIndex();
                    Vec3 val = ReadVec3();
                    anim.AnimationPositionKeys[boneName].push_back({ frame, val });
                }
            }

            // Rotation keys
            if (hasRot) {
                uint32_t keyCount = ReadKeyCount();
                for (uint32_t k = 0; k < keyCount; k++) {
                    uint32_t frame = ReadFrameIndex();
                    Quat val = ReadQuat();
                    anim.AnimationRotationKeys[boneName].push_back({ frame, val });
                }
            }

            // Scale keys — NEW: properly read scale keys
            if (hasScale) {
                uint32_t keyCount = ReadKeyCount();
                for (uint32_t k = 0; k < keyCount; k++) {
                    uint32_t frame = ReadFrameIndex();
                    Vec3 val = ReadVec3();
                    anim.AnimationScaleKeys[boneName].push_back({ frame, val });
                }
            }
        }

        // Read notetracks — IMPORTANT for weapon timing events
        if (hasNotes) {
            for (uint32_t i = 0; i < notificationCount; i++) {
                uint32_t frame = ReadFrameIndex();
                std::string note = ReadString();
                anim.AnimationNotetracks[note].push_back(frame);
            }
        }

        // Read blendshape footer (optional)
        if (pos + 16 <= buf.size()) {
            uint64_t footerMagic = ReadU64();
            if (footerMagic == 0xA646E656C424553ULL) {
                // Skip blendshape data (not needed for SMD)
            } else {
                pos -= 8;
            }
        }

        return true;
    }

private:
    uint32_t ReadKeyCount() {
        if (frameCount <= 0xFF) return ReadU8();
        else if (frameCount <= 0xFFFF) return ReadU16();
        else return ReadU32();
    }

    uint32_t ReadFrameIndex() {
        if (frameCount <= 0xFF) return ReadU8();
        else if (frameCount <= 0xFFFF) return ReadU16();
        else return ReadU32();
    }

    uint8_t ReadU8() { if (pos >= buf.size()) return 0; return buf[pos++]; }
    uint16_t ReadU16() { if (pos + 2 > buf.size()) return 0; uint16_t v = *(uint16_t*)(buf.data() + pos); pos += 2; return v; }
    uint32_t ReadU32() { if (pos + 4 > buf.size()) return 0; uint32_t v = *(uint32_t*)(buf.data() + pos); pos += 4; return v; }
    uint64_t ReadU64() { if (pos + 8 > buf.size()) return 0; uint64_t v = *(uint64_t*)(buf.data() + pos); pos += 8; return v; }
    float ReadF32() { if (pos + 4 > buf.size()) return 0; float v; memcpy(&v, buf.data() + pos, 4); pos += 4; return v; }
    Vec3 ReadVec3() { float x = ReadF32(), y = ReadF32(), z = ReadF32(); return { x, y, z }; }
    Quat ReadQuat() { float x = ReadF32(), y = ReadF32(), z = ReadF32(), w = ReadF32(); return { x, y, z, w }; }

    std::string ReadString() {
        std::string s;
        while (pos < buf.size() && buf[pos] != 0) s += (char)buf[pos++];
        if (pos < buf.size()) pos++;
        return s;
    }

    uint16_t version = 0, headerSize = 0;
    uint8_t animTypeRaw = 0, flags = 0, dataPresent = 0, dataProperties = 0;
    float frameRate = 30.0f;
    uint32_t frameCount = 0, boneCount = 0, notificationCount = 0;
    uint8_t modifierCount = 0;
    bool hasPos = false, hasRot = false, hasScale = false, hasNotes = false;
    bool looping = false;
    WraithAnimType animType = WraithAnimType::Absolute;
};
