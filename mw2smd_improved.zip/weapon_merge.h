#pragma once
#include "wraith_types.h"
#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <set>
#include <algorithm>

// ===========================================================================
//  Enhanced Weapon Merging System
//  
//  Improvements over original:
//    - Multi-attachment point detection and handling
//    - Weapon part auto-detection (magazine, bolt, barrel, etc.)
//    - Proper bone chain preservation for animated weapon parts
//    - Magazine/clip bone fix — ensures clip attaches to correct bone
//    - Perfect transform computation with quaternion math
//    - Support for weapons with multiple moving parts
// ===========================================================================

struct WeaponMergeSystem {

    // ===========================================================================
    //  Compute global transforms for all bones in a WraithModel
    // ===========================================================================
    static void ComputeGlobalTransforms(WraithModel& wm) {
        std::vector<bool> done(wm.Bones.size(), false);
        for (int iter = 0; iter < (int)wm.Bones.size() * 2; iter++) {
            for (size_t i = 0; i < wm.Bones.size(); i++) {
                if (done[i]) continue;
                auto& b = wm.Bones[i];
                if (b.BoneParent < 0) {
                    b.GlobalPosition = b.LocalPosition;
                    b.GlobalRotation = b.LocalRotation;
                    done[i] = true;
                } else if ((size_t)b.BoneParent < wm.Bones.size() && done[b.BoneParent]) {
                    auto& pb = wm.Bones[b.BoneParent];
                    b.GlobalRotation = pb.GlobalRotation * b.LocalRotation;
                    Quat pv(b.LocalPosition.x, b.LocalPosition.y, b.LocalPosition.z, 0);
                    Quat rpv = pb.GlobalRotation * pv * pb.GlobalRotation.Conjugate();
                    b.GlobalPosition = {
                        pb.GlobalPosition.x + rpv.x,
                        pb.GlobalPosition.y + rpv.y,
                        pb.GlobalPosition.z + rpv.z
                    };
                    done[i] = true;
                }
            }
        }
    }

    // ===========================================================================
    //  Find the best attachment bone in the primary model
    //  Tries multiple common attachment point names
    // ===========================================================================
    static int FindBestAttachmentBone(const WraithModel& primary, const std::string& preferredBone) {
        // First try the user-specified bone
        for (size_t i = 0; i < primary.Bones.size(); i++)
            if (primary.Bones[i].TagName == preferredBone) return (int)i;

        // Try common weapon attachment bones
        std::vector<std::string> fallbackBones = {
            "tag_weapon_left", "tag_weapon_right", "tag_weapon",
            "tag_weapon2", "tag_akimbo", "tag_butt",
            "j_gun", "tag_gun", "bip01_r_hand", "bip01_l_hand"
        };

        for (auto& boneName : fallbackBones) {
            for (size_t i = 0; i < primary.Bones.size(); i++)
                if (primary.Bones[i].TagName == boneName) return (int)i;
        }

        // Case-insensitive fallback
        for (auto& boneName : fallbackBones) {
            std::string lo = boneName;
            std::transform(lo.begin(), lo.end(), lo.begin(), ::tolower);
            for (size_t i = 0; i < primary.Bones.size(); i++) {
                std::string bl = primary.Bones[i].TagName;
                std::transform(bl.begin(), bl.end(), bl.begin(), ::tolower);
                if (bl == lo) return (int)i;
            }
        }

        return -1; // Not found
    }

    // ===========================================================================
    //  Detect all weapon parts from bone names
    // ===========================================================================
    static std::vector<WeaponPartInfo> DetectWeaponParts(const WraithModel& weapon) {
        std::vector<WeaponPartInfo> parts;

        for (size_t i = 0; i < weapon.Bones.size(); i++) {
            auto partType = DetectWeaponPartType(weapon.Bones[i].TagName);
            if (partType != WeaponPartType::Unknown) {
                parts.push_back({
                    weapon.Bones[i].TagName,
                    partType,
                    (int)i,
                    weapon.Bones[i].BoneParent
                });
            }
        }

        return parts;
    }

    // ===========================================================================
    //  Get the root bone of the weapon (highest in hierarchy)
    // ===========================================================================
    static int FindWeaponRoot(const WraithModel& weapon) {
        // First try to find a bone explicitly marked as root
        for (int i = 0; i < (int)weapon.Bones.size(); i++)
            if (weapon.Bones[i].BoneParent < 0)
                return i;

        // Fallback: find the first bone
        return weapon.Bones.empty() ? -1 : 0;
    }

    // ===========================================================================
    //  Enhanced Merge: Merge weapon model into primary (arms/hands) model
    //
    //  Key improvements:
    //    1. Multi-attachment point support
    //    2. Weapon part detection and preservation
    //    3. Proper magazine/clip bone handling
    //    4. Perfect transform computation
    //    5. Animated part bone chain preservation
    // ===========================================================================
    static bool MergeWraithModels(
        WraithModel& primary,
        const WraithModel& weapon,
        const std::string& attachBone,
        float scale,
        std::vector<WeaponPartInfo>* outParts = nullptr
    ) {
        // Step 1: Ensure global transforms are computed
        bool primaryHasGlobal = false;
        for (auto& b : primary.Bones) {
            if (!b.GlobalPosition.zero() || b.GlobalRotation.w != 1 ||
                b.GlobalRotation.x != 0 || b.GlobalRotation.y != 0 || b.GlobalRotation.z != 0) {
                primaryHasGlobal = true; break;
            }
        }
        if (!primaryHasGlobal) ComputeGlobalTransforms(primary);

        WraithModel wmWeapon = weapon; // mutable copy
        bool weaponHasGlobal = false;
        for (auto& b : wmWeapon.Bones) {
            if (!b.GlobalPosition.zero() || b.GlobalRotation.w != 1 ||
                b.GlobalRotation.x != 0 || b.GlobalRotation.y != 0 || b.GlobalRotation.z != 0) {
                weaponHasGlobal = true; break;
            }
        }
        if (!weaponHasGlobal) ComputeGlobalTransforms(wmWeapon);

        // Step 2: Find attachment bone in primary
        int attachIdx = FindBestAttachmentBone(primary, attachBone);
        if (attachIdx < 0) {
            std::cerr << "ERROR: Attachment bone \"" << attachBone << "\" not found in primary model\n";
            std::cerr << "  Available bones:\n";
            for (auto& b : primary.Bones)
                std::cerr << "    " << b.TagName << "\n";
            return false;
        }
        std::cout << "  Attaching weapon to bone: " << primary.Bones[attachIdx].TagName
                  << " (index " << attachIdx << ")\n";

        // Step 3: Detect weapon parts
        auto weaponParts = DetectWeaponParts(wmWeapon);
        if (!weaponParts.empty()) {
            std::cout << "  Detected weapon parts:\n";
            for (auto& part : weaponParts) {
                std::cout << "    " << part.boneName << " -> ";
                switch (part.partType) {
                    case WeaponPartType::Body: std::cout << "Body"; break;
                    case WeaponPartType::Magazine: std::cout << "Magazine"; break;
                    case WeaponPartType::MagazineEmpty: std::cout << "Empty Magazine"; break;
                    case WeaponPartType::Bolt: std::cout << "Bolt"; break;
                    case WeaponPartType::Barrel: std::cout << "Barrel"; break;
                    case WeaponPartType::Stock: std::cout << "Stock"; break;
                    case WeaponPartType::Grip: std::cout << "Grip"; break;
                    case WeaponPartType::Scope: std::cout << "Scope"; break;
                    case WeaponPartType::IronSight: std::cout << "Iron Sight"; break;
                    case WeaponPartType::Muzzle: std::cout << "Muzzle"; break;
                    case WeaponPartType::Laser: std::cout << "Laser"; break;
                    case WeaponPartType::GrenadeLauncher: std::cout << "Grenade Launcher"; break;
                    case WeaponPartType::Bipod: std::cout << "Bipod"; break;
                    case WeaponPartType::Trigger: std::cout << "Trigger"; break;
                    case WeaponPartType::Receiver: std::cout << "Receiver"; break;
                    case WeaponPartType::Slide: std::cout << "Slide"; break;
                    case WeaponPartType::Cylinder: std::cout << "Cylinder"; break;
                    case WeaponPartType::Pump: std::cout << "Pump"; break;
                    case WeaponPartType::CarryHandle: std::cout << "Carry Handle"; break;
                    case WeaponPartType::Silencer: std::cout << "Silencer"; break;
                    case WeaponPartType::AmmoBelt: std::cout << "Ammo Belt"; break;
                    case WeaponPartType::ChargingHandle: std::cout << "Charging Handle"; break;
                    case WeaponPartType::Safety: std::cout << "Safety"; break;
                    case WeaponPartType::CaseEjector: std::cout << "Case Ejector"; break;
                    default: std::cout << "Unknown"; break;
                }
                std::cout << "\n";
            }
        }

        int primaryBoneCount = (int)primary.Bones.size();
        int weaponBoneCount = (int)wmWeapon.Bones.size();

        // Step 4: Build remap table and find weapon root
        std::vector<int> weaponToMerged(weaponBoneCount);
        for (int i = 0; i < weaponBoneCount; i++)
            weaponToMerged[i] = primaryBoneCount + i;

        int weaponRootIdx = FindWeaponRoot(wmWeapon);
        if (weaponRootIdx < 0) weaponRootIdx = 0;

        // Step 5: Get attachment bone's global transform
        Vec3 attPos = primary.Bones[attachIdx].GlobalPosition;
        Quat attRot = primary.Bones[attachIdx].GlobalRotation;

        // Step 6: Find special bones that need specific attachment handling
        // Magazine/clip bones should be checked for special parenting
        int magazineBoneIdx = -1;
        for (int i = 0; i < weaponBoneCount; i++) {
            auto pt = DetectWeaponPartType(wmWeapon.Bones[i].TagName);
            if (pt == WeaponPartType::Magazine || pt == WeaponPartType::MagazineEmpty) {
                magazineBoneIdx = i;
                break;
            }
        }

        // Step 7: Merge bones with proper transform computation
        //
        // CRITICAL FIX: Weapon root bones (j_gun etc.) sit at their own file's
        // local origin by convention. "Preserving" that global (0,0,0) when
        // reparenting under the hand attach bone welds the weapon to the
        // compiled model's world origin — completely ignoring where the hand
        // actually is. Correct socket behavior: weld with zero local offset.
        for (int i = 0; i < weaponBoneCount; i++) {
            WraithBone wb = wmWeapon.Bones[i];
            bool isRoot = (i == weaponRootIdx);
            bool isMagazine = (i == magazineBoneIdx);

            if (isRoot) {
                wb.BoneParent = attachIdx;

                double origLen = wb.GlobalPosition.len();
                double origRotDev = std::abs(1.0 - std::abs(wb.GlobalRotation.w));
                if (origLen > 0.5 || origRotDev > 0.01) {
                    std::cerr << "  WARNING: weapon root \"" << wb.TagName
                              << "\" is not at its file origin (offset len=" << origLen
                              << ", rot deviation=" << origRotDev
                              << "). Welding to \"" << primary.Bones[attachIdx].TagName
                              << "\" with zero offset — if the weapon looks wrong, this file "
                              << "may need a real attach offset.\n";
                }

                // Socket weld: weapon origin sits exactly on the attach bone
                wb.LocalPosition = { 0, 0, 0 };
                wb.LocalRotation = { 0, 0, 0, 1 };
                wb.GlobalPosition = attPos;
                wb.GlobalRotation = attRot;
                wb.IsWeaponRoot = true;

            } else if (isMagazine) {
                // Magazine bone: ensure it maintains proper hierarchy under weapon
                int oldParent = wb.BoneParent;
                if (oldParent >= 0 && oldParent < weaponBoneCount) {
                    wb.BoneParent = weaponToMerged[oldParent];
                } else {
                    wb.BoneParent = weaponToMerged[weaponRootIdx];
                }
            } else {
                // Regular bone: remap parent index into merged skeleton
                int oldParent = wb.BoneParent;
                if (oldParent >= 0 && oldParent < weaponBoneCount)
                    wb.BoneParent = weaponToMerged[oldParent];
            }

            // NOTE: scale is intentionally NOT applied here.
            // WraithModelToSmdScene() scales every bone and vertex uniformly later.
            // Scaling here double-applied it to merged weapon data only.
            (void)scale;
            primary.Bones.push_back(wb);
        }

        // Step 8: Merge submeshes with remapped bone indices
        int meshIdxOffset = (int)primary.Submeshes.size();
        (void)meshIdxOffset;
        for (auto& submesh : wmWeapon.Submeshes) {
            primary.Submeshes.push_back(submesh);
            auto& ns = primary.Submeshes.back();

            // Remap bone indices in weights
            for (auto& v : ns.Vertices) {
                for (auto& w : v.Weights) {
                    if (w.BoneIndex < (uint32_t)weaponBoneCount)
                        w.BoneIndex = (uint32_t)weaponToMerged[w.BoneIndex];
                }
                for (auto& w : v.FullWeights) {
                    if (w.BoneIndex < (uint32_t)weaponBoneCount)
                        w.BoneIndex = (uint32_t)weaponToMerged[w.BoneIndex];
                }
            }

            // NOTE: vertex scale intentionally NOT applied here either —
            // WraithModelToSmdScene() scales all triangles uniformly later.
        }

        // Step 9: Merge materials (avoid duplicates)
        std::set<std::string> existingMatNames;
        for (auto& m : primary.Materials) existingMatNames.insert(m.MaterialName);
        for (auto& mat : wmWeapon.Materials) {
            if (existingMatNames.find(mat.MaterialName) == existingMatNames.end()) {
                primary.Materials.push_back(mat);
                existingMatNames.insert(mat.MaterialName);
            }
        }

        // Step 10: Store weapon part info if requested
        if (outParts) {
            for (auto& part : weaponParts) {
                WeaponPartInfo mergedPart = part;
                mergedPart.originalBoneIndex = weaponToMerged[part.originalBoneIndex];
                mergedPart.parentBoneIndex = (part.parentBoneIndex >= 0 && part.parentBoneIndex < weaponBoneCount)
                    ? weaponToMerged[part.parentBoneIndex] : attachIdx;
                outParts->push_back(mergedPart);
            }
        }

        std::cout << "  Weapon merge complete: " << weaponBoneCount << " bones, "
                  << wmWeapon.Submeshes.size() << " submeshes merged\n";

        return true;
    }

    // ===========================================================================
    //  Validate merged model integrity
    // ===========================================================================
    static bool ValidateMerge(const WraithModel& model, std::string* errors = nullptr) {
        bool valid = true;
        std::string err;

        // Check for bone parent references out of range
        for (size_t i = 0; i < model.Bones.size(); i++) {
            int parent = model.Bones[i].BoneParent;
            if (parent >= (int)model.Bones.size()) {
                err += "Bone " + std::to_string(i) + " (" + model.Bones[i].TagName +
                      ") has invalid parent index " + std::to_string(parent) + "\n";
                valid = false;
            }
        }

        // Check for weight bone indices out of range
        for (size_t mi = 0; mi < model.Submeshes.size(); mi++) {
            for (size_t vi = 0; vi < model.Submeshes[mi].Vertices.size(); vi++) {
                for (auto& w : model.Submeshes[mi].Vertices[vi].Weights) {
                    if (w.BoneIndex >= (uint32_t)model.Bones.size()) {
                        err += "Mesh " + std::to_string(mi) + " vert " + std::to_string(vi) +
                              " has invalid bone index " + std::to_string(w.BoneIndex) + "\n";
                        valid = false;
                    }
                }
            }
        }

        if (errors) *errors = err;
        return valid;
    }

    // ===========================================================================
    //  Remap bones that exceed the GoldSrc 64-bone limit
    //  Strategy: merge small bones into their parents, then remove them
    //  Returns the bone index remap table (old -> new)
    // ===========================================================================
    static std::vector<int> RemapOverlimitBones(WraithModel& model, int maxBones = 64,
        std::map<std::string, std::string>* outNameRemap = nullptr) {
        int boneCount = (int)model.Bones.size();
        if (boneCount <= maxBones) {
            std::vector<int> identity(boneCount);
            for (int i = 0; i < boneCount; i++) identity[i] = i;
            return identity;
        }

        std::vector<int> remap(boneCount);
        for (int i = 0; i < boneCount; i++) remap[i] = i;

        // Count vertices per bone
        std::vector<int> boneVertCount(boneCount, 0);
        for (auto& submesh : model.Submeshes) {
            for (auto& vert : submesh.Vertices) {
                for (auto& w : vert.Weights) {
                    if (w.BoneIndex < (uint32_t)boneCount && w.Weight > 0.01f) {
                        boneVertCount[w.BoneIndex]++;
                    }
                }
            }
        }

        // Strategy: iteratively merge the bone with fewest vertices into its parent
        // until we're under the limit
        int currentCount = boneCount;
        while (currentCount > maxBones) {
            // Find the bone with fewest vertices (excluding root)
            int bestBone = -1;
            int bestCount = INT_MAX;
            for (int i = 1; i < boneCount; i++) {
                if (remap[i] != i) continue; // already remapped
                if (boneVertCount[i] < bestCount) {
                    bestCount = boneVertCount[i];
                    bestBone = i;
                }
            }
            if (bestBone < 0) break;

            // Find the closest non-remapped parent
            int parent = model.Bones[bestBone].BoneParent;
            while (parent >= 0 && remap[parent] != parent) {
                parent = model.Bones[parent].BoneParent;
            }
            if (parent < 0) parent = 0;

            // Merge this bone into its parent
            remap[bestBone] = parent;
            boneVertCount[parent] += boneVertCount[bestBone];
            boneVertCount[bestBone] = 0;
            currentCount--;

            std::cout << "  Merging bone " << bestBone << " (" << model.Bones[bestBone].TagName
                     << ", " << bestCount << " verts) -> bone " << parent
                     << " (" << model.Bones[parent].TagName << ")\n";
        }

        // Build name-to-name remap for animations (BEFORE updating remap table)
        // At this point, remap[i] != i means bone i was merged into remap[i]
        if (outNameRemap) {
            for (int i = 0; i < boneCount; i++) {
                if (remap[i] != i) {
                    std::string fromName = model.Bones[i].TagName;
                    int targetIdx = remap[i]; // target's OLD index
                    std::string toName = model.Bones[targetIdx].TagName;
                    (*outNameRemap)[fromName] = toName;
                }
            }
        }

        // Build new bone list (only keep bones that map to themselves)
        std::vector<int> oldToNew(boneCount, -1);
        std::vector<WraithBone> newBones;
        for (int i = 0; i < boneCount; i++) {
            if (remap[i] == i) {
                oldToNew[i] = (int)newBones.size();
                WraithBone b = model.Bones[i];
                if (b.BoneParent >= 0 && b.BoneParent < boneCount) {
                    // Follow merge chain to find the surviving ancestor
                    int effectiveParent = remap[b.BoneParent];
                    b.BoneParent = oldToNew[effectiveParent];
                    if (b.BoneParent < 0) b.BoneParent = 0;
                }
                newBones.push_back(b);
            }
        }

        // Build final remap: old index -> new index (for ALL bones)
        std::vector<int> finalRemap(boneCount, 0);
        for (int i = 0; i < boneCount; i++) {
            if (remap[i] == i) {
                // Kept bone: map to its new compacted index
                finalRemap[i] = oldToNew[i];
            } else {
                // Merged bone: map to the new index of its merge target
                finalRemap[i] = oldToNew[remap[i]];
            }
            if (finalRemap[i] < 0) finalRemap[i] = 0;
        }

        // Apply final remap to ALL vertex weights
        for (auto& submesh : model.Submeshes) {
            for (auto& vert : submesh.Vertices) {
                for (auto& w : vert.Weights) {
                    if (w.BoneIndex < (uint32_t)boneCount) {
                        w.BoneIndex = (uint32_t)finalRemap[w.BoneIndex];
                    }
                }
                for (auto& w : vert.FullWeights) {
                    if (w.BoneIndex < (uint32_t)boneCount) {
                        w.BoneIndex = (uint32_t)finalRemap[w.BoneIndex];
                    }
                }
            }
        }

        // Replace model bones
        model.Bones = newBones;

        // Copy finalRemap to output remap
        remap = finalRemap;

        std::cout << "  Bone remap complete: " << boneCount << " -> " << model.Bones.size() << " bones\n";
        return remap;
    }
};
